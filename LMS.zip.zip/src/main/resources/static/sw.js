const CACHE_NAME='local-library-shell-v7';
const APP_SHELL=[
  '/',
  '/index.html',
  '/login.html',
  '/dashboard.html',
  '/books.html',
  '/book-form.html',
  '/copies.html',
  '/members.html',
  '/member-form.html',
  '/borrowings.html',
  '/returns.html',
  '/reservations.html',
  '/fines.html',
  '/profile.html',
  '/reports.html',
  '/offline.html',
  '/manifest.json',
  '/css/style.css',
  '/js/common.js',
  '/js/login.js',
  '/js/dashboard.js',
  '/js/books.js',
  '/js/members.js',
  '/js/borrowings.js',
  '/js/reservations.js',
  '/js/fines.js',
  '/js/profile.js',
  '/js/reports.js',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/icon-maskable-512.png'
];

function cacheableResponse(response){
  const headers=new Headers(response.headers);
  headers.delete('cache-control');
  headers.delete('pragma');
  headers.delete('expires');
  headers.delete('vary');
  return new Response(response.clone().body,{
    status:response.status,
    statusText:response.statusText,
    headers
  });
}

self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE_NAME).then(cache=>Promise.all(APP_SHELL.map(async path=>{
    const response=await fetch(path);
    if(!response.ok)throw new Error(`Failed to cache app resource ${path}: HTTP ${response.status}`);
    await cache.put(path,cacheableResponse(response));
  }))));
  self.skipWaiting();
});

self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(
    keys.filter(key=>key.startsWith('local-library-shell-')&&key!==CACHE_NAME)
      .map(key=>caches.delete(key))
  )));
  self.clients.claim();
});

self.addEventListener('fetch',event=>{
  const request=event.request;
  const url=new URL(request.url);
  if(request.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/'))return;
  if(request.mode==='navigate'){
    event.respondWith(fetch(request).then(response=>{
      if(response.ok)caches.open(CACHE_NAME).then(cache=>cache.put(request,response.clone()));
      return response;
    }).catch(async()=>{
      const cached=await caches.match(request,{ignoreSearch:true});
      return cached||caches.match('/offline.html');
    }));
    return;
  }
  event.respondWith(caches.match(request).then(cached=>cached||fetch(request).then(response=>{
    if(response.ok)caches.open(CACHE_NAME).then(cache=>cache.put(request,cacheableResponse(response)));
    return response;
  })));
});
