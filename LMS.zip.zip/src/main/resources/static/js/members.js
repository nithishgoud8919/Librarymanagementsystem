Library.ready.then(async user=>{
  if(!user)return;
  const esc=Library.esc;
  if(document.querySelector('#member-search')){
    const form=document.querySelector('#member-search'),out=document.querySelector('#members-list');
    const load=async()=>{try{
      const params=new URLSearchParams(Object.fromEntries([...new FormData(form)].filter(([,v])=>v.trim()))),items=await Library.api('/api/users?'+params);
      out.innerHTML=Library.renderTable(['Name','Email','Role','Phone','Status','Registered','Actions'],items.map(u=>`<tr><td>${esc(u.fullName)}</td><td>${esc(u.email)}</td><td>${Library.badge(u.role)}</td><td>${esc(u.phone||'—')}</td><td>${Library.badge(u.status)}</td><td>${Library.date((u.createdAt||'').slice(0,10))}</td><td>${user.role==='ADMIN'?`<button class="button secondary small" data-status="${u.id}" data-next="${u.status==='ACTIVE'?'SUSPENDED':'ACTIVE'}">${u.status==='ACTIVE'?'Suspend':'Activate'}</button>`:''}</td></tr>`));
      out.querySelectorAll('[data-status]').forEach(button=>button.onclick=async()=>{try{await Library.api(`/api/users/${button.dataset.status}/status`,{method:'PATCH',body:JSON.stringify({status:button.dataset.next})});Library.toast('Account status updated');load();}catch(e){Library.toast(e.message,true);}});
    }catch(e){out.innerHTML=`<p class="message error">${esc(e.message)}</p>`;}};
    form.onsubmit=e=>{e.preventDefault();load();};load();
  }
  if(document.querySelector('#member-form')){
    const roleField=document.querySelector('#role-field');
    if(user.role==='ADMIN')roleField.classList.remove('hidden');
    else roleField.remove();
    document.querySelector('#member-form').elements.password.autocomplete='new-password';
    document.querySelector('#member-form').onsubmit=async e=>{e.preventDefault();const data=Library.formData(e.currentTarget);data.role=e.currentTarget.elements.role?.value||'MEMBER';
      try{await Library.api('/api/users',{method:'POST',body:JSON.stringify(data)});Library.toast('Member account created');location.href='/members.html';}
      catch(error){const out=document.querySelector('#form-error');out.textContent=error.message;out.hidden=false;}
    };
  }
});
