Library.ready.then(async user=>{
  if(!user)return;const out=document.querySelector('#report-result'),esc=Library.esc;
  const endpoints={inventory:'/api/reports/inventory',borrowings:'/api/reports/borrowings',overdue:'/api/reports/overdue',fines:'/api/reports/fines','most-borrowed':'/api/reports/most-borrowed',categories:'/api/reports/categories'};
  const activeRows=(key,data)=>{
    if(key==='inventory')return Library.renderTable(['Book','Author','Category','Copies'],(data.books||[]).map(b=>`<tr><td>${esc(b.title)}</td><td>${esc(b.author)}</td><td>${esc(b.category)}</td><td>${b.copies.length} · ${b.copies.filter(c=>c.status==='AVAILABLE').length} available</td></tr>`));
    if(key==='borrowings'||key==='overdue')return Library.renderTable(['Member','Book','Copy','Due date','Status'],(data.borrowings||[]).map(b=>`<tr><td>${esc(b.memberName)}</td><td>${esc(b.bookTitle)}</td><td>${esc(b.copyCode)}</td><td>${Library.date(b.dueDate)}</td><td>${Library.badge(b.status)}</td></tr>`));
    if(key==='fines')return Library.renderTable(['Member','Amount','Paid','Reason','Status'],(data.fines||[]).map(f=>`<tr><td>${esc(f.memberName)}</td><td>${Number(f.amount).toFixed(2)}</td><td>${Number(f.paidAmount).toFixed(2)}</td><td>${esc(f.reason)}</td><td>${Library.badge(f.status)}</td></tr>`));
    if(key==='most-borrowed')return Library.renderTable(['Book','Author','Borrow count'],(data.books||[]).map(b=>`<tr><td>${esc(b.title)}</td><td>${esc(b.author)}</td><td>${b.borrowCount}</td></tr>`));
    return Library.renderTable(['Category','Books'],(data.categories||[]).map(c=>`<tr><td>${esc(c.category)}</td><td>${c.bookCount}</td></tr>`));
  };
  async function show(key){
    out.innerHTML='<div class="loading">Loading report…</div>';
    try{
      if(key==='member-history'){
        const memberId=prompt('Enter the member account ID:');if(!memberId){out.innerHTML='<div class="empty">Enter a member ID to view borrowing history.</div>';return;}
        out.innerHTML=Library.renderTable(['Member','Book','Copy','Issue date','Due date','Returned','Status'],(await Library.api(`/api/reports/member-history?memberId=${encodeURIComponent(memberId)}`)).borrowings.map(b=>`<tr><td>${esc(b.memberName)}</td><td>${esc(b.bookTitle)}</td><td>${esc(b.copyCode)}</td><td>${Library.date(b.issueDate)}</td><td>${Library.date(b.dueDate)}</td><td>${Library.date(b.returnDate)}</td><td>${Library.badge(b.status)}</td></tr>`));
        return;
      }
      out.innerHTML=activeRows(key,await Library.api(endpoints[key]));
    }
    catch(e){out.innerHTML=`<p class="message error">${esc(e.message)}</p>`;}
  }
  document.querySelectorAll('[data-report]').forEach(button=>button.onclick=()=>{document.querySelectorAll('[data-report]').forEach(b=>b.classList.remove('active'));button.classList.add('active');show(button.dataset.report);});
  const history=document.createElement('button');history.className='button secondary';history.dataset.report='member-history';history.textContent='Member history';document.querySelector('.report-tabs').append(history);
  history.onclick=()=>{document.querySelectorAll('[data-report]').forEach(b=>b.classList.remove('active'));history.classList.add('active');show('member-history');};
  const first=document.querySelector('[data-report]');first.classList.add('active');show(first.dataset.report);
});
