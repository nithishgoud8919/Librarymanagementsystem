(function(){
  let installPrompt=null;
  function addInstallButton(){
    const parent=document.querySelector('.user-menu')||document.querySelector('.login-card');
    if(!installPrompt||!parent||document.querySelector('#install-app'))return;
    const button=document.createElement('button');
    button.id='install-app';
    button.type='button';
    button.className='button secondary small';
    button.textContent='Install app';
    button.addEventListener('click',async()=>{
      if(!installPrompt)return;
      try{
        await installPrompt.prompt();
        await installPrompt.userChoice;
        installPrompt=null;
        button.remove();
      }catch(error){
        toast(`Could not start installation: ${error.message}`,true);
      }
    });
    parent.append(button);
  }
  window.addEventListener('beforeinstallprompt',event=>{
    event.preventDefault();
    installPrompt=event;
    addInstallButton();
  });
  window.addEventListener('appinstalled',()=>{
    installPrompt=null;
    document.querySelector('#install-app')?.remove();
  });
  const registerServiceWorker=()=>navigator.serviceWorker.register('/sw.js')
    .catch(error=>console.error('Could not register the Local Library service worker.',error));
  if('serviceWorker' in navigator){
    if(document.readyState==='complete')registerServiceWorker();
    else window.addEventListener('load',registerServiceWorker,{once:true});
  }
  const roleNames={ADMIN:'Administrator',LIBRARIAN:'Librarian',MEMBER:'Member'};
  const links=[['dashboard.html','Dashboard','ALL'],['books.html','Catalog','ALL'],['copies.html','Copies','STAFF'],['members.html','Members','STAFF'],['borrowings.html','Issue book','STAFF'],['returns.html','Returns','STAFF'],['reservations.html','Reservations','ALL'],['fines.html','Fines','ALL'],['reports.html','Reports','STAFF']];
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  async function api(url,options={}){
    const opts={credentials:'same-origin',...options,headers:{...(options.body?{'Content-Type':'application/json'}:{}),...(options.headers||{})}};
    const response=await fetch(url,opts);const type=response.headers.get('content-type')||'';
    const data=type.includes('json')?await response.json():null;
    if(!response.ok){if(response.status===401&&location.pathname!=='/'&&!location.pathname.endsWith('login.html'))location.href='/login.html';throw new Error(data?.error||`Request failed (${response.status})`);}
    return data;
  }
  function toast(message,error=false){const el=document.querySelector('#toast');if(!el)return;el.textContent=message;el.className='toast show'+(error?' error':'');setTimeout(()=>el.className='toast',3200);}
  function badge(status){const value=String(status||'');let kind='';if(['ACTIVE','AVAILABLE','PAID','READY','RETURNED','NEW','GOOD','FULFILLED'].includes(value))kind='good';else if(['OVERDUE','PENDING','PARTIALLY_PAID','WAITING','RESERVED'].includes(value))kind='warn';else if(['SUSPENDED','DEACTIVATED','ARCHIVED','DAMAGED','LOST','CANCELLED','WAIVED','POOR'].includes(value))kind='bad';return `<span class="badge ${kind}">${esc(value.replaceAll('_',' '))}</span>`;}
  function renderTable(headers,rows,empty='No records found.'){
    if(!rows?.length)return `<div class="empty">${esc(empty)}</div>`;
    const content=document.createElement('template');
    content.innerHTML=rows.join('');
    content.content.querySelectorAll('tr').forEach(row=>row.querySelectorAll('td').forEach((cell,index)=>{
      if(headers[index])cell.dataset.label=headers[index];
    }));
    return `<table class="table"><thead><tr>${headers.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${content.innerHTML}</tbody></table>`;
  }
  function formData(form){return Object.fromEntries(new FormData(form).entries());}
  function date(value){return value?new Date(value+'T00:00:00').toLocaleDateString():'—';}
  async function currentUser(){return api('/api/auth/me');}
  function setupNavigation(user){
    const root=document.querySelector('#topbar');if(!root)return;
    const role=user.role,staff=role!=='MEMBER',path=location.pathname.split('/').pop()||'dashboard.html';
    const visible=links.filter(([, ,mode])=>mode==='ALL'||staff);
    if(role==='MEMBER'){visible.splice(2,0,['borrowings.html','My loans','ALL']);}
    root.className='topbar';
    root.innerHTML=`<a class="wordmark" href="/dashboard.html">LOCAL LIBRARY</a><nav class="nav-links">${visible.map(([href,label])=>`<a class="${path===href?'active':''}" href="/${href}">${label}</a>`).join('')}</nav><div class="user-menu"><span>${esc(user.fullName)} · ${roleNames[role]||esc(role)}</span><a href="/profile.html">Profile</a><button id="logout" class="button secondary small">Log out</button></div>`;
    root.querySelector('#logout').addEventListener('click',async()=>{try{await api('/api/auth/logout',{method:'POST'});}finally{location.href='/login.html';}});
    addInstallButton();
  }
  const ready=(async()=>{
    const path=location.pathname;
    if(path==='/'||path.endsWith('/login.html'))return null;
    try{const user=await currentUser();window.libraryUser=user;setupNavigation(user);return user;}
    catch(error){location.href='/login.html';return null;}
  })();
  window.Library={api,toast,badge,renderTable,formData,date,esc,ready,roleNames};
})();
