Library.ready.then(async user=>{
  if(!user)return;
  const esc=Library.esc;
  if(document.querySelector('#search-form')){
    const form=document.querySelector('#search-form'),list=document.querySelector('#books-list');
    if(user.role==='MEMBER')document.querySelector('#add-book').remove();
    const load=async()=>{
      list.innerHTML='<div class="loading">Loading catalog…</div>';
      try{
        const params=new URLSearchParams(Object.fromEntries([...new FormData(form)].filter(([,v])=>v.trim())));
        const books=await Library.api('/api/books?'+params);
        list.innerHTML=Library.renderTable(['Book','Author','Category','ISBN','Availability','Actions'],books.map(b=>`<tr><td><details><summary><strong>${esc(b.title)}</strong></summary><p>${esc(b.description||'No description available.')}</p><small>${esc(b.publisher||'')} · ${esc(b.publicationYear||'Year unknown')} · ${esc(b.language||'')}</small></details></td><td>${esc(b.author)}</td><td>${esc(b.category)}</td><td>${esc(b.isbn)}</td><td>${b.availableCopies} / ${b.totalCopies} available</td><td><div class="actions">${user.role!=='MEMBER'?`<a class="button secondary small" href="/copies.html?bookId=${b.id}">Copies</a><a class="button secondary small" href="/book-form.html?id=${b.id}">Edit</a><button class="button danger small" data-archive="${b.id}">Archive</button>`:b.availableCopies===0?`<button class="button primary small" data-reserve="${b.id}">Reserve</button>`:'—'}</div></td></tr>`));
        list.querySelectorAll('[data-archive]').forEach(button=>button.onclick=async()=>{if(confirm('Archive this book?'))try{await Library.api(`/api/books/${button.dataset.archive}/archive`,{method:'PATCH'});Library.toast('Book archived');load();}catch(e){Library.toast(e.message,true);}});
        list.querySelectorAll('[data-reserve]').forEach(button=>button.onclick=async()=>{try{await Library.api('/api/reservations',{method:'POST',body:JSON.stringify({bookId:Number(button.dataset.reserve)})});Library.toast('Reservation placed');load();}catch(e){Library.toast(e.message,true);}});
      }catch(e){list.innerHTML=`<p class="message error">${esc(e.message)}</p>`;}
    };
    form.onsubmit=e=>{e.preventDefault();load();};document.querySelector('#clear-search').onclick=()=>{form.reset();load();};load();
  }
  if(document.querySelector('#book-form')){
    const form=document.querySelector('#book-form'),id=new URLSearchParams(location.search).get('id');
    if(id){document.querySelector('#form-title').textContent='Edit book';const book=await Library.api(`/api/books/${id}`);for(const [key,value] of Object.entries(book))if(form.elements[key])form.elements[key].value=value??'';}
    form.onsubmit=async e=>{e.preventDefault();const body=Library.formData(form);body.publicationYear=body.publicationYear?Number(body.publicationYear):null;
      try{await Library.api(id?`/api/books/${id}`:'/api/books',{method:id?'PUT':'POST',body:JSON.stringify(body)});Library.toast('Book saved');location.href='/books.html';}
      catch(error){const out=document.querySelector('#form-error');out.textContent=error.message;out.hidden=false;}
    };
  }
  if(document.querySelector('#copy-form')){
    const form=document.querySelector('#copy-form'),select=document.querySelector('#copy-book');
    try{
      const books=await Library.api('/api/books');select.innerHTML=books.map(b=>`<option value="${b.id}">${esc(b.title)}</option>`).join('');
      const params=new URLSearchParams(location.search);if(params.has('bookId'))select.value=params.get('bookId');
      const refresh=async()=>{
        const rows=await Library.api('/api/copies');
        document.querySelector('#copies-list').innerHTML=Library.renderTable(['Book','Copy code','Rack / row','Condition','Status','Update'],rows.filter(c=>!select.value||c.bookId===Number(select.value)).map(c=>`<tr><td>${esc(c.bookTitle)}</td><td>${esc(c.copyCode)}</td><td><input data-shelf="${c.id}" value="${esc(c.shelfLocation||'')}" aria-label="Rack / row location"></td><td><select data-condition-edit="${c.id}">${['NEW','GOOD','DAMAGED','POOR'].map(v=>`<option ${c.condition===v?'selected':''}>${v}</option>`).join('')}</select></td><td>${Library.badge(c.status)}</td><td><div class="actions"><select data-status-edit="${c.id}"><option value="AVAILABLE" ${c.status==='AVAILABLE'?'selected':''}>AVAILABLE</option><option value="DAMAGED" ${c.status==='DAMAGED'?'selected':''}>DAMAGED</option><option value="LOST" ${c.status==='LOST'?'selected':''}>LOST</option><option value="ARCHIVED" ${c.status==='ARCHIVED'?'selected':''}>ARCHIVED</option></select><button class="button secondary small" data-save-copy="${c.id}">Save</button></div></td></tr>`));
        document.querySelectorAll('[data-save-copy]').forEach(button=>button.onclick=async()=>{
          const id=button.dataset.saveCopy;
          try{
            await Library.api(`/api/copies/${id}`,{method:'PUT',body:JSON.stringify({shelfLocation:document.querySelector(`[data-shelf="${id}"]`).value,condition:document.querySelector(`[data-condition-edit="${id}"]`).value})});
            const status=document.querySelector(`[data-status-edit="${id}"]`).value;
            if(!['BORROWED','RESERVED'].includes(rows.find(c=>c.id===Number(id)).status))await Library.api(`/api/copies/${id}/status`,{method:'PATCH',body:JSON.stringify({status})});
            Library.toast('Copy updated');refresh();
          }catch(error){Library.toast(error.message,true);}
        });
      };
      select.onchange=refresh;form.onsubmit=async e=>{e.preventDefault();const selectedBook=select.value;try{const created=await Library.api(`/api/books/${selectedBook}/copies/batch`,{method:'POST',body:JSON.stringify({quantity:Number(form.elements.quantity.value),shelfLocation:form.elements.shelfLocation.value,condition:form.elements.condition.value})});Library.toast(`${created.length} ${created.length===1?'copy':'copies'} added`);form.reset();select.value=params.get('bookId')||selectedBook;refresh();}catch(error){Library.toast(error.message,true);}};
      await refresh();
    }catch(error){Library.toast(error.message,true);}
  }
});
