Library.ready.then(async user=>{
  if(!user)return;
  const esc=Library.esc;
  const collectionPageSize=5;
  let collectionPage=0;
  let collectionSearch='';
  const path=user.role==='ADMIN'?'/api/dashboard/admin':user.role==='LIBRARIAN'?'/api/dashboard/librarian':'/api/dashboard/member';
  try{
    const data=await Library.api(path),cards=document.querySelector('#dashboard-cards'),detail=document.querySelector('#dashboard-detail');
    let collection=data.collection;
    if(user.role==='MEMBER'&&!Array.isArray(collection)){
      const books=await Library.api('/api/books');
      collection=await Promise.all(books.map(async book=>({
        id:book.id,title:book.title,author:book.author,category:book.category,publisher:book.publisher,
        publicationYear:book.publicationYear,totalCopies:book.totalCopies,availableCopies:book.availableCopies,
        copies:(await Library.api(`/api/books/${book.id}/copies`)).map(copy=>({
          copyCode:copy.copyCode,shelfLocation:copy.shelfLocation
        }))
      })));
    }
    document.querySelector('#welcome').textContent=`Good day, ${user.fullName.split(' ')[0]}`;
    let stats=[];
    if(user.role==='ADMIN')stats=[['Total librarians',data.totalLibrarians],['Total members',data.totalMembers],['Total titles',data.totalBooks],['Total no. of books',data.totalCopies],['Available books',data.availableCopies],['Books taken',data.activeBorrowings],['Overdue books',data.overdueBorrowings]];
    else if(user.role==='LIBRARIAN')stats=[['Issued today',data.issuedToday],['Returned today',data.returnedToday],['Overdue books',data.overdueBooks],['Pending reservations',data.pendingReservations],['Available copies',data.availableCopies],['Unavailable copies',data.unavailableCopies]];
    else stats=[];
    cards.innerHTML=stats.map(([label,value])=>`<article class="stat-card"><span class="stat-label">${Library.esc(label)}</span><strong>${Library.esc(value)}</strong><div class="stat-note">${user.role==='MEMBER'?'Personal account':'Library operations'}</div></article>`).join('');
    if(user.role==='ADMIN'){
      detail.closest('.panel').hidden=true;
    }else if(user.role==='MEMBER'){
      cards.hidden=true;
      document.querySelector('#dashboard-subtitle').textContent='Your current loans and the library collection.';
      document.querySelector('#detail-title').textContent='Current loans';
      detail.innerHTML=Library.renderTable(['Book','Copy','Issued','Due','Status'],data.currentLoans.map(x=>`<tr><td>${Library.esc(x.bookTitle)}</td><td>${Library.esc(x.copyCode)}</td><td>${Library.date(x.issueDate)}</td><td>${Library.date(x.dueDate)}</td><td>${Library.badge(x.status)}</td></tr>`),'You have no active loans.');
      document.querySelector('#collection-panel').hidden=false;
      const searchForm=document.querySelector('#collection-search');
      const searchInput=document.querySelector('#collection-search-input');
      const pagination=document.querySelector('#collection-pagination');
      const previous=document.querySelector('#collection-previous');
      const next=document.querySelector('#collection-next');
      const pageInfo=document.querySelector('#collection-page-info');
      const renderCollection=()=>{
        const query=collectionSearch.trim().toLocaleLowerCase();
        const filtered=collection.filter(book=>{
          const searchable=[book.title,book.author,book.category,book.publisher,book.publicationYear,
            ...book.copies.flatMap(copy=>[copy.copyCode,copy.shelfLocation])]
            .filter(value=>value!=null).join(' ').toLocaleLowerCase();
          return searchable.includes(query);
        });
        const pageCount=Math.ceil(filtered.length/collectionPageSize);
        collectionPage=Math.min(collectionPage,Math.max(0,pageCount-1));
        const pageBooks=filtered.slice(collectionPage*collectionPageSize,(collectionPage+1)*collectionPageSize);
        const collectionRows=pageBooks.map(book=>{
          const rackCounts=new Map();
          book.copies.forEach(copy=>{
            const rack=copy.shelfLocation?.trim()||'Location not recorded';
            rackCounts.set(rack,(rackCounts.get(rack)||0)+1);
          });
          const locations=rackCounts.size
            ?[...rackCounts].map(([rack,count])=>`Rack / row ${esc(rack)} — ${count} ${count===1?'copy':'copies'}`).join(' · ')
            :'No physical copies registered';
          return {
            desktop:`<tr><td>${esc(book.title)}</td><td>${esc(book.author)}</td><td>${esc(book.category)}</td><td>${esc(book.publisher||'—')}</td><td>${esc(book.publicationYear||'—')}</td><td>${book.totalCopies}</td><td>${book.availableCopies}</td><td>${locations}</td></tr>`,
            mobile:`<article class="collection-card"><p class="collection-line collection-title"><strong>${esc(book.title)}</strong><span>${esc(book.author)}</span></p><p class="collection-line collection-publication"><span>${esc(book.category)}</span><span>${esc(book.publisher||'—')}</span><span>${esc(book.publicationYear||'—')}</span></p><p class="collection-line collection-stock"><strong>${book.availableCopies} of ${book.totalCopies} available</strong><span>${locations}</span></p></article>`
          };
        });
        const desktop=Library.renderTable(['Title','Author','Category','Publisher','Publication year','Copies','Available','Rack / row locations'],collectionRows.map(row=>row.desktop),'No books match your search.');
        const mobile=collectionRows.length?collectionRows.map(row=>row.mobile).join(''):'<div class="empty">No books match your search.</div>';
        document.querySelector('#collection-detail').innerHTML=`<div class="collection-desktop">${desktop}</div><div class="collection-mobile">${mobile}</div>`;
        pagination.hidden=pageCount<=1;
        pageInfo.textContent=pageCount?`Page ${collectionPage+1} of ${pageCount} · ${filtered.length} books`:'0 books';
        previous.disabled=collectionPage===0;
        next.disabled=collectionPage>=pageCount-1;
      };
      searchInput.addEventListener('input',()=>{
        collectionSearch=searchInput.value;
        collectionPage=0;
        renderCollection();
      });
      searchForm.addEventListener('reset',()=>{
        collectionSearch='';
        collectionPage=0;
        requestAnimationFrame(renderCollection);
      });
      previous.addEventListener('click',()=>{collectionPage--;renderCollection();});
      next.addEventListener('click',()=>{collectionPage++;renderCollection();});
      renderCollection();
    }else{
      const members=data.recentMembers||[];
      document.querySelector('#detail-title').textContent='Recently registered members';
      detail.innerHTML=Library.renderTable(['Member','Email','Registered'],members.map(x=>`<tr><td>${Library.esc(x.fullName)}</td><td>${Library.esc(x.email)}</td><td>${Library.date((x.createdAt||'').slice(0,10))}</td></tr>`),'No recently registered members.');
    }
  }catch(e){Library.toast(e.message,true);}
});
