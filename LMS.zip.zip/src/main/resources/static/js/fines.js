Library.ready.then(async user=>{
  if(!user)return;const root=document.querySelector('#fines-list'),esc=Library.esc;
  try{
    const items=await Library.api(user.role==='MEMBER'?'/api/fines/mine':'/api/fines');
    root.innerHTML=Library.renderTable(['Member','Transaction','Amount','Paid','Balance','Reason','Status','Actions'],items.map(f=>{
      const remaining=(Number(f.amount)-Number(f.paidAmount)).toFixed(2);
      return `<tr><td>${esc(f.memberName)}</td><td>#${f.transactionId}</td><td>${Number(f.amount).toFixed(2)}</td><td>${Number(f.paidAmount).toFixed(2)}</td><td>${remaining}</td><td>${esc(f.reason)}</td><td>${Library.badge(f.status)}</td><td>${user.role!=='MEMBER'&&['PENDING','PARTIALLY_PAID'].includes(f.status)?`<div class="actions"><button class="button secondary small" data-pay="${f.id}" data-remaining="${remaining}">Record payment</button><button class="button danger small" data-waive="${f.id}">Waive</button></div>`:''}</td></tr>`;
    }),'No fines found.');
    root.querySelectorAll('[data-pay]').forEach(button=>button.onclick=async()=>{
      const amount=prompt(`Payment amount (remaining balance ${button.dataset.remaining}):`);if(!amount)return;
      try{await Library.api(`/api/fines/${button.dataset.pay}/payment`,{method:'POST',body:JSON.stringify({amount:Number(amount),notes:'Recorded at local library'})});Library.toast('Payment recorded');location.reload();}catch(e){Library.toast(e.message,true);}
    });
    root.querySelectorAll('[data-waive]').forEach(button=>button.onclick=async()=>{if(!confirm('Waive this fine?'))return;try{await Library.api(`/api/fines/${button.dataset.waive}/waive`,{method:'POST',body:JSON.stringify({reason:'Waived by staff'})});Library.toast('Fine waived');location.reload();}catch(e){Library.toast(e.message,true);}});
  }catch(e){root.innerHTML=`<p class="message error">${esc(e.message)}</p>`;}
});
