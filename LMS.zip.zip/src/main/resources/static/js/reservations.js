Library.ready.then(async user=>{
  if(!user)return;const root=document.querySelector('#reservations-list'),esc=Library.esc;
  try{
    const items=await Library.api(user.role==='MEMBER'?'/api/reservations/mine':'/api/reservations');
    root.innerHTML=Library.renderTable(['Member','Book','Placed','Ready until','Status','Action'],items.map(r=>`<tr><td>${esc(r.memberName)}</td><td>${esc(r.bookTitle)}</td><td>${Library.date(r.reservationDate)}</td><td>${Library.date(r.expiryDate)}</td><td>${Library.badge(r.status)}</td><td>${['WAITING','READY'].includes(r.status)?`<button class="button danger small" data-cancel="${r.id}">Cancel</button>`:''}</td></tr>`),'No reservations found.');
    root.querySelectorAll('[data-cancel]').forEach(button=>button.onclick=async()=>{try{await Library.api(`/api/reservations/${button.dataset.cancel}/cancel`,{method:'PATCH'});Library.toast('Reservation cancelled');location.reload();}catch(e){Library.toast(e.message,true);}});
  }catch(e){root.innerHTML=`<p class="message error">${esc(e.message)}</p>`;}
});
