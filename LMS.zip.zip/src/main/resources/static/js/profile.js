Library.ready.then(async user=>{
  if(!user)return;const form=document.querySelector('#profile-form');
  for(const [key,value] of Object.entries({fullName:user.fullName,email:user.email,phone:user.phone||'',role:user.role,address:user.address||''}))form.elements[key].value=value;
  form.onsubmit=async event=>{event.preventDefault();try{const body=Library.formData(form);await Library.api(`/api/users/${user.id}/profile`,{method:'PUT',body:JSON.stringify({fullName:body.fullName,phone:body.phone,address:body.address})});Library.toast('Profile updated');}catch(e){Library.toast(e.message,true);}};
});
