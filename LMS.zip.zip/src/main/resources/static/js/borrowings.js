Library.ready.then(async user=>{
  if(!user)return;const esc=Library.esc;
  if(user.role==='MEMBER'&&document.querySelector('#issue-form')){
    document.querySelector('#issue-form').remove();
    document.querySelector('h1').textContent='My borrowing history';
    document.querySelector('.page-heading .muted').textContent='Your current and previous loans, issue dates, and due dates.';
    document.querySelector('.page-heading.compact h2').textContent='Borrowing history';
  }
  if(document.querySelector('#issue-form')){
    const form=document.querySelector('#issue-form'),member=document.querySelector('#issue-member'),copy=document.querySelector('#issue-copy');
    const issueDate=form.elements.issueDate;
    const today=new Date();
    const localToday=new Date(today.getTime()-today.getTimezoneOffset()*60000).toISOString().slice(0,10);
    issueDate.max=localToday;
    issueDate.value=localToday;
    try{
      const [members,copies]=await Promise.all([Library.api('/api/users?role=MEMBER'),Library.api('/api/copies')]);
      member.innerHTML='<option value="">Select member</option>'+members.filter(m=>m.status==='ACTIVE').map(m=>`<option value="${m.id}">${esc(m.fullName)} · ${esc(m.email)}</option>`).join('');
      copy.innerHTML='<option value="">Select available copy</option>'+copies.filter(c=>c.status==='AVAILABLE'||c.status==='RESERVED').map(c=>`<option value="${c.id}">${esc(c.bookTitle)} · ${esc(c.copyCode)} · ${c.status}</option>`).join('');
      form.onsubmit=async e=>{e.preventDefault();try{await Library.api('/api/borrowings',{method:'POST',body:JSON.stringify({memberId:Number(member.value),copyId:Number(copy.value),issueDate:issueDate.value})});Library.toast('Book issued');form.reset();issueDate.value=localToday;loadList();}catch(error){Library.toast(error.message,true);}};
    }catch(e){Library.toast(e.message,true);}
  }
  async function loadList(){
    const root=document.querySelector('#borrowings-list')||document.querySelector('#returns-list');if(!root)return;
    root.innerHTML='<div class="loading">Loading borrowing records…</div>';
    try{
      const items=await Library.api(user.role==='MEMBER'?`/api/users/${user.id}/borrowings`:'/api/borrowings'),active=items.filter(x=>['ACTIVE','OVERDUE'].includes(x.status));
      if(user.role==='MEMBER'){
        root.innerHTML=Library.renderTable(['Book','Copy','Issue date','Due date','Returned','Status'],items.map(x=>`<tr><td>${esc(x.bookTitle)}</td><td>${esc(x.copyCode)}</td><td>${Library.date(x.issueDate)}</td><td>${Library.date(x.dueDate)}</td><td>${Library.date(x.returnDate)}</td><td>${Library.badge(x.dueDate<new Date().toISOString().slice(0,10)&&['ACTIVE','OVERDUE'].includes(x.status)?'OVERDUE':x.status)}</td></tr>`),'You have no borrowing history.');
        return;
      }
      if(document.querySelector('#returns-list')){
        root.innerHTML=Library.renderTable(['Member','Book / copy','Issue date','Due date','Status','Action'],active.map(x=>`<tr><td>${esc(x.memberName)}</td><td>${esc(x.bookTitle)}<div class="muted">${esc(x.copyCode)}</div></td><td>${Library.date(x.issueDate)}</td><td>${Library.date(x.dueDate)}</td><td>${Library.badge(x.dueDate<new Date().toISOString().slice(0,10)?'OVERDUE':x.status)}</td><td><div class="actions"><select data-condition="${x.id}"><option>GOOD</option><option>NEW</option><option>DAMAGED</option><option>POOR</option></select><button class="button primary small" data-return="${x.id}">Return</button><button class="button danger small" data-lost="${x.id}">Lost</button></div></td></tr>`),'No active books to return.');
        root.querySelectorAll('[data-return]').forEach(button=>button.onclick=()=>submitReturn(button.dataset.return,root.querySelector(`[data-condition="${button.dataset.return}"]`).value,false));
        root.querySelectorAll('[data-lost]').forEach(button=>button.onclick=()=>{if(confirm('Record this copy as lost? A replacement fine will be created.'))submitReturn(button.dataset.lost,'POOR',true);});
      }else root.innerHTML=Library.renderTable(['Member','Book / copy','Issue date','Due date','Status'],items.map(x=>`<tr><td>${esc(x.memberName)}</td><td>${esc(x.bookTitle)}<div class="muted">${esc(x.copyCode)}</div></td><td>${Library.date(x.issueDate)}</td><td>${Library.date(x.dueDate)}</td><td>${Library.badge(x.status)}</td></tr>`),'No borrowing records.');
    }catch(e){root.innerHTML=`<p class="message error">${esc(e.message)}</p>`;}
  }
  async function submitReturn(id,condition,lost){try{await Library.api(`/api/borrowings/${id}/return`,{method:'POST',body:JSON.stringify({condition,lost})});Library.toast(lost?'Copy marked lost':'Return recorded');loadList();}catch(e){Library.toast(e.message,true);}}
  loadList();
});
