document.querySelector('#login-form')?.addEventListener('submit',async event=>{
  event.preventDefault();const form=event.currentTarget;const error=document.querySelector('#login-error');error.hidden=true;
  try{const data=Object.fromEntries(new FormData(form));await Library.api('/api/auth/login',{method:'POST',body:JSON.stringify(data)});location.href='/dashboard.html';}
  catch(e){error.textContent=e.message;error.hidden=false;}
});
