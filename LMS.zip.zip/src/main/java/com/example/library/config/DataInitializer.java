package com.example.library.config;

import com.example.library.entity.*;
import com.example.library.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {
    @Bean CommandLineRunner seed(RoleRepository roles,UserRepository users,BookRepository books,BookCopyRepository copies,PasswordEncoder encoder){
        return args->{
            for(String name:new String[]{"ADMIN","LIBRARIAN","MEMBER"})if(roles.findByName(name).isEmpty())roles.save(new Role(name));
            if(users.findByEmailIgnoreCase("admin@library.local").isEmpty())
                users.save(new User("Library Administrator","admin@library.local",encoder.encode("Admin@123"),null,null,roles.findByName("ADMIN").orElseThrow()));
            if(users.findByEmailIgnoreCase("librarian@library.local").isEmpty())
                users.save(new User("Sample Librarian","librarian@library.local",encoder.encode("Librarian@123"),null,null,roles.findByName("LIBRARIAN").orElseThrow()));
            if(users.findByEmailIgnoreCase("member@library.local").isEmpty())
                users.save(new User("Sample Member","member@library.local",encoder.encode("Member@123"),"555-0100","Local library",roles.findByName("MEMBER").orElseThrow()));
            if(books.count()==0){
                Book b1=books.save(new Book("The Great Gatsby","9780743273565","A novel set in the Jazz Age.","F. Scott Fitzgerald","Fiction","Scribner",1925,"English"));
                Book b2=books.save(new Book("Pride and Prejudice","9780141439518","A classic novel of manners.","Jane Austen","Fiction","Penguin Classics",1813,"English"));
                Book b3=books.save(new Book("A Brief History of Time","9780553380163","An introduction to cosmology.","Stephen Hawking","Science","Bantam",1988,"English"));
                copies.save(new BookCopy(b1,"FIC-0001","A1-01",CopyCondition.GOOD));copies.save(new BookCopy(b1,"FIC-0002","A1-01",CopyCondition.NEW));
                copies.save(new BookCopy(b2,"FIC-0003","A1-02",CopyCondition.GOOD));copies.save(new BookCopy(b3,"SCI-0001","B2-01",CopyCondition.GOOD));
            }
        };
    }
}
