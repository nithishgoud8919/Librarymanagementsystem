package com.example.library.config;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class DesktopBrowserLauncher {
    private static final Logger log = LoggerFactory.getLogger(DesktopBrowserLauncher.class);

    private final Environment environment;

    public DesktopBrowserLauncher(Environment environment) {
        this.environment = environment;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void openLibrary() {
        if (!environment.getProperty("library.desktop.open-browser", Boolean.class, false)) {
            return;
        }

        try {
            if (!Desktop.isDesktopSupported()) {
                log.error("Could not open the library page: desktop browser integration is unavailable.");
                return;
            }
            Desktop.getDesktop().browse(URI.create("http://localhost:8080/login.html"));
        } catch (IOException | UnsupportedOperationException exception) {
            log.error("Could not open the library page in a browser.", exception);
        }
    }
}
