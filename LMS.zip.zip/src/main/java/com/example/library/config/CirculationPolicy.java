package com.example.library.config;
import java.math.BigDecimal;
public final class CirculationPolicy {
    private CirculationPolicy() {}
    public static final int MAX_ACTIVE_BOOKS=5;
    public static final int BORROWING_DAYS=14;
    public static final int RESERVATION_HOLD_DAYS=3;
    public static final BigDecimal DAILY_FINE_RATE=new BigDecimal("1.00");
    public static final BigDecimal LOST_COPY_FEE=new BigDecimal("25.00");
    public static final BigDecimal SERIOUS_UNPAID_FINE_LIMIT=new BigDecimal("10.00");
}
