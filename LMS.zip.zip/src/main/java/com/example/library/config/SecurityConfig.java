package com.example.library.config;

import com.example.library.repository.UserRepository;
import com.example.library.security.SessionAuthenticationFilter;
import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.*;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {
    @Bean PasswordEncoder passwordEncoder(){return new BCryptPasswordEncoder();}
    @Bean SecurityFilterChain securityFilterChain(HttpSecurity http,UserRepository users) throws Exception {
        return http.csrf(csrf->csrf.disable())
            .authorizeHttpRequests(auth->auth.requestMatchers("/api/auth/login","/api/auth/logout","/","/*.html","/css/**","/js/**","/favicon.ico").permitAll()
                .requestMatchers("/api/**").authenticated().anyRequest().permitAll())
            .sessionManagement(session->session.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED))
            .exceptionHandling(errors->errors.authenticationEntryPoint((request,response,ex)->{
                response.setStatus(401);response.setContentType("application/json");response.getWriter().write("{\"error\":\"Authentication required\"}");
            }))
            .addFilterBefore(new SessionAuthenticationFilter(users),UsernamePasswordAuthenticationFilter.class).build();
    }
}
