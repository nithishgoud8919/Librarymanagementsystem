package com.example.library.entity;
public enum BookStatus { ACTIVE, ARCHIVED }
