package com.example.library.entity;
public enum ReservationStatus { WAITING, READY, FULFILLED, CANCELLED, EXPIRED }
