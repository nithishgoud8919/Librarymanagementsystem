package com.example.library.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name="fines")
public class Fine {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @OneToOne(optional=false, fetch=FetchType.EAGER) @JoinColumn(nullable=false, unique=true) private BorrowTransaction borrowTransaction;
    @ManyToOne(optional=false, fetch=FetchType.EAGER) private User member;
    @Column(nullable=false, precision=10, scale=2) private BigDecimal amount;
    @Column(nullable=false, precision=10, scale=2) private BigDecimal paidAmount=BigDecimal.ZERO;
    @Enumerated(EnumType.STRING) @Column(nullable=false, length=20) private FineStatus status=FineStatus.PENDING;
    @Column(nullable=false, length=500) private String reason;
    @Column(nullable=false, updatable=false) private LocalDateTime createdAt;
    @Column(nullable=false) private LocalDateTime updatedAt;
    protected Fine(){}
    public Fine(BorrowTransaction transaction,User member,BigDecimal amount,String reason){this.borrowTransaction=transaction;this.member=member;this.amount=amount;this.reason=reason;}
    @PrePersist void insertDates(){createdAt=LocalDateTime.now();updatedAt=createdAt;} @PreUpdate void updateDate(){updatedAt=LocalDateTime.now();}
    public Long getId(){return id;} public BorrowTransaction getBorrowTransaction(){return borrowTransaction;} public User getMember(){return member;}
    public BigDecimal getAmount(){return amount;} public BigDecimal getPaidAmount(){return paidAmount;} public void setPaidAmount(BigDecimal v){paidAmount=v;}
    public FineStatus getStatus(){return status;} public void setStatus(FineStatus v){status=v;} public String getReason(){return reason;} public void setReason(String v){reason=v;}
    public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;}
}
