package com.example.library.entity;
public enum AccountStatus { ACTIVE, SUSPENDED, DEACTIVATED }
