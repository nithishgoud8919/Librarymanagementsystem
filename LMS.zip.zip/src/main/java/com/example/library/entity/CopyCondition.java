package com.example.library.entity;
public enum CopyCondition { NEW, GOOD, DAMAGED, POOR }
