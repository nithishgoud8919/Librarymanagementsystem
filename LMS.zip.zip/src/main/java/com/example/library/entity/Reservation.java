package com.example.library.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name="reservations")
public class Reservation {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional=false, fetch=FetchType.EAGER) private User member;
    @ManyToOne(optional=false, fetch=FetchType.EAGER) private Book book;
    @Column(nullable=false) private LocalDate reservationDate;
    private LocalDate readyDate;
    private LocalDate expiryDate;
    @Enumerated(EnumType.STRING) @Column(nullable=false, length=16) private ReservationStatus status=ReservationStatus.WAITING;
    @Column(nullable=false, updatable=false) private LocalDateTime createdAt;
    @Column(nullable=false) private LocalDateTime updatedAt;
    protected Reservation(){}
    public Reservation(User member,Book book){this.member=member;this.book=book;this.reservationDate=LocalDate.now();}
    @PrePersist void insertDates(){createdAt=LocalDateTime.now();updatedAt=createdAt;} @PreUpdate void updateDate(){updatedAt=LocalDateTime.now();}
    public Long getId(){return id;} public User getMember(){return member;} public Book getBook(){return book;} public LocalDate getReservationDate(){return reservationDate;}
    public LocalDate getReadyDate(){return readyDate;} public void setReadyDate(LocalDate v){readyDate=v;} public LocalDate getExpiryDate(){return expiryDate;}
    public void setExpiryDate(LocalDate v){expiryDate=v;} public ReservationStatus getStatus(){return status;} public void setStatus(ReservationStatus v){status=v;}
}
