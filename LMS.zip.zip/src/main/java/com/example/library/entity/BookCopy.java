package com.example.library.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="book_copies", uniqueConstraints=@UniqueConstraint(columnNames="copy_code"))
public class BookCopy {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional=false, fetch=FetchType.EAGER) private Book book;
    @Column(name="copy_code", nullable=false, unique=true, length=80) private String copyCode;
    @Column(length=80) private String shelfLocation;
    @Enumerated(EnumType.STRING) @Column(name="copy_condition", nullable=false, length=16) private CopyCondition condition=CopyCondition.GOOD;
    @Enumerated(EnumType.STRING) @Column(nullable=false, length=16) private CopyStatus status=CopyStatus.AVAILABLE;
    @Column(nullable=false, updatable=false) private LocalDateTime createdAt;
    @Column(nullable=false) private LocalDateTime updatedAt;
    protected BookCopy(){}
    public BookCopy(Book book,String copyCode,String shelfLocation,CopyCondition condition){this.book=book;this.copyCode=copyCode;this.shelfLocation=shelfLocation;this.condition=condition;}
    @PrePersist void insertDates(){createdAt=LocalDateTime.now();updatedAt=createdAt;} @PreUpdate void updateDate(){updatedAt=LocalDateTime.now();}
    public Long getId(){return id;} public Book getBook(){return book;} public void setBook(Book v){book=v;} public String getCopyCode(){return copyCode;}
    public void setCopyCode(String v){copyCode=v;} public String getShelfLocation(){return shelfLocation;} public void setShelfLocation(String v){shelfLocation=v;}
    public CopyCondition getCondition(){return condition;} public void setCondition(CopyCondition v){condition=v;} public CopyStatus getStatus(){return status;}
    public void setStatus(CopyStatus v){status=v;} public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;}
}
