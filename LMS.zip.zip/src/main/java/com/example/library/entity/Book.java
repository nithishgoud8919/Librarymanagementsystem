package com.example.library.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="books", uniqueConstraints=@UniqueConstraint(columnNames="isbn"))
public class Book {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(nullable=false, length=240) private String title;
    @Column(nullable=false, unique=true, length=32) private String isbn;
    @Column(length=3000) private String description;
    @Column(nullable=false, length=160) private String author;
    @Column(nullable=false, length=100) private String category;
    @Column(length=160) private String publisher;
    private Integer publicationYear;
    @Column(length=80) private String language;
    @Enumerated(EnumType.STRING) @Column(nullable=false, length=16) private BookStatus status=BookStatus.ACTIVE;
    @Column(nullable=false, updatable=false) private LocalDateTime createdAt;
    @Column(nullable=false) private LocalDateTime updatedAt;
    protected Book(){}
    public Book(String title,String isbn,String description,String author,String category,String publisher,Integer publicationYear,String language){
        this.title=title;this.isbn=isbn;this.description=description;this.author=author;this.category=category;this.publisher=publisher;this.publicationYear=publicationYear;this.language=language;
    }
    @PrePersist void insertDates(){createdAt=LocalDateTime.now();updatedAt=createdAt;} @PreUpdate void updateDate(){updatedAt=LocalDateTime.now();}
    public Long getId(){return id;} public String getTitle(){return title;} public void setTitle(String v){title=v;} public String getIsbn(){return isbn;}
    public void setIsbn(String v){isbn=v;} public String getDescription(){return description;} public void setDescription(String v){description=v;}
    public String getAuthor(){return author;} public void setAuthor(String v){author=v;} public String getCategory(){return category;}
    public void setCategory(String v){category=v;} public String getPublisher(){return publisher;} public void setPublisher(String v){publisher=v;}
    public Integer getPublicationYear(){return publicationYear;} public void setPublicationYear(Integer v){publicationYear=v;} public String getLanguage(){return language;}
    public void setLanguage(String v){language=v;} public BookStatus getStatus(){return status;} public void setStatus(BookStatus v){status=v;}
    public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;}
}
