package com.example.library.entity;
public enum CopyStatus { AVAILABLE, BORROWED, RESERVED, DAMAGED, LOST, ARCHIVED }
