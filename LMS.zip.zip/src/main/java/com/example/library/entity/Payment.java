package com.example.library.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name="payments")
public class Payment {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional=false, fetch=FetchType.EAGER) private Fine fine;
    @Column(nullable=false, precision=10, scale=2) private BigDecimal amount;
    @Column(nullable=false) private LocalDateTime paymentDate;
    @ManyToOne(optional=false, fetch=FetchType.EAGER) private User recordedBy;
    @Column(length=300) private String notes;
    protected Payment(){}
    public Payment(Fine fine,BigDecimal amount,User recordedBy,String notes){this.fine=fine;this.amount=amount;this.recordedBy=recordedBy;this.notes=notes;this.paymentDate=LocalDateTime.now();}
    public Long getId(){return id;} public Fine getFine(){return fine;} public BigDecimal getAmount(){return amount;} public LocalDateTime getPaymentDate(){return paymentDate;}
    public User getRecordedBy(){return recordedBy;} public String getNotes(){return notes;}
}
