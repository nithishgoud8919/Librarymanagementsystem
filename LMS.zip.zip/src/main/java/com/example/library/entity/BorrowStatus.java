package com.example.library.entity;
public enum BorrowStatus { ACTIVE, OVERDUE, RETURNED, LOST }
