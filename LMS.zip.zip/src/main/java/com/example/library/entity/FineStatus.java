package com.example.library.entity;
public enum FineStatus { PENDING, PAID, WAIVED, PARTIALLY_PAID }
