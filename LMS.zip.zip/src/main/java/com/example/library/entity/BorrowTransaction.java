package com.example.library.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name="borrow_transactions")
public class BorrowTransaction {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional=false, fetch=FetchType.EAGER) private User member;
    @ManyToOne(optional=false, fetch=FetchType.EAGER) private BookCopy bookCopy;
    @Column(nullable=false) private LocalDate issueDate;
    @Column(nullable=false) private LocalDate dueDate;
    private LocalDate returnDate;
    @Enumerated(EnumType.STRING) @Column(nullable=false, length=16) private BorrowStatus status=BorrowStatus.ACTIVE;
    @ManyToOne(optional=false, fetch=FetchType.EAGER) private User issuedBy;
    @ManyToOne(fetch=FetchType.EAGER) private User returnedBy;
    @Column(nullable=false, updatable=false) private LocalDateTime createdAt;
    @Column(nullable=false) private LocalDateTime updatedAt;
    protected BorrowTransaction(){}
    public BorrowTransaction(User member,BookCopy copy,LocalDate issueDate,LocalDate dueDate,User issuer){this.member=member;this.bookCopy=copy;this.issueDate=issueDate;this.dueDate=dueDate;this.issuedBy=issuer;}
    @PrePersist void insertDates(){createdAt=LocalDateTime.now();updatedAt=createdAt;} @PreUpdate void updateDate(){updatedAt=LocalDateTime.now();}
    public Long getId(){return id;} public User getMember(){return member;} public BookCopy getBookCopy(){return bookCopy;} public LocalDate getIssueDate(){return issueDate;}
    public LocalDate getDueDate(){return dueDate;} public LocalDate getReturnDate(){return returnDate;} public void setReturnDate(LocalDate v){returnDate=v;}
    public BorrowStatus getStatus(){return (status==BorrowStatus.ACTIVE&&dueDate!=null&&dueDate.isBefore(LocalDate.now()))?BorrowStatus.OVERDUE:status;} public void setStatus(BorrowStatus v){status=v;} public User getIssuedBy(){return issuedBy;}
    public User getReturnedBy(){return returnedBy;} public void setReturnedBy(User v){returnedBy=v;}
}
