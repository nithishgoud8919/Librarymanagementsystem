package com.example.library.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "users", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false, length = 120) private String fullName;
    @Column(nullable = false, unique = true, length = 180) private String email;
    @Column(nullable = false) private String password;
    @Column(length = 32) private String phone;
    @Column(length = 500) private String address;
    @ManyToOne(optional = false, fetch = FetchType.EAGER) private Role role;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 20) private AccountStatus status = AccountStatus.ACTIVE;
    @Column(nullable = false, updatable = false) private LocalDateTime createdAt;
    @Column(nullable = false) private LocalDateTime updatedAt;
    protected User() {}
    public User(String fullName, String email, String password, String phone, String address, Role role) {
        this.fullName=fullName; this.email=email; this.password=password; this.phone=phone; this.address=address; this.role=role;
    }
    @PrePersist void insertDates() { createdAt=LocalDateTime.now(); updatedAt=createdAt; }
    @PreUpdate void updateDate() { updatedAt=LocalDateTime.now(); }
    public Long getId(){return id;} public String getFullName(){return fullName;} public void setFullName(String v){fullName=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;} public String getPassword(){return password;}
    public void setPassword(String v){password=v;} public String getPhone(){return phone;} public void setPhone(String v){phone=v;}
    public String getAddress(){return address;} public void setAddress(String v){address=v;} public Role getRole(){return role;}
    public void setRole(Role v){role=v;} public AccountStatus getStatus(){return status;} public void setStatus(AccountStatus v){status=v;}
    public LocalDateTime getCreatedAt(){return createdAt;} public LocalDateTime getUpdatedAt(){return updatedAt;}
}
