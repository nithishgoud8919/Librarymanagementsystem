package com.example.library.service;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.*;
import com.example.library.exception.LibraryException;
import com.example.library.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Service
public class ReservationService {
    private final ReservationRepository reservations;private final UserService users;private final BookService books;private final BookCopyRepository copies;
    public ReservationService(ReservationRepository reservations,UserService users,BookService books,BookCopyRepository copies){this.reservations=reservations;this.users=users;this.books=books;this.copies=copies;}
    private ReservationView view(Reservation r){return new ReservationView(r.getId(),r.getMember().getId(),r.getMember().getFullName(),r.getBook().getId(),r.getBook().getTitle(),r.getReservationDate(),r.getReadyDate(),r.getExpiryDate(),r.getStatus());}
    @Transactional(readOnly=true) public List<ReservationView> list(Long memberId){
        return (memberId==null?reservations.findAllByOrderByReservationDateAsc():reservations.findByMember_IdOrderByReservationDateDesc(memberId)).stream().map(this::view).toList();
    }
    @Transactional public ReservationView create(Long memberId,Long bookId){
        User member=users.getEntity(memberId);Book book=books.entity(bookId);
        if(!member.getRole().getName().equals("MEMBER")||member.getStatus()!=AccountStatus.ACTIVE)throw LibraryException.badRequest("An active member account is required");
        if(book.getStatus()!=BookStatus.ACTIVE)throw LibraryException.badRequest("Archived books cannot be reserved");
        if(copies.countByBook_IdAndStatus(bookId,CopyStatus.AVAILABLE)>0)throw LibraryException.badRequest("An available copy exists; reserve only when no copy is available");
        if(reservations.existsByMember_IdAndBook_IdAndStatusIn(memberId,bookId,List.of(ReservationStatus.WAITING,ReservationStatus.READY)))throw LibraryException.conflict("You already have an active reservation for this book");
        return view(reservations.save(new Reservation(member,book)));
    }
    @Transactional public void cancel(Long id,Long actorId,boolean librarian){
        Reservation r=reservations.findById(id).orElseThrow(()->LibraryException.notFound("Reservation not found"));
        if(!librarian&&!r.getMember().getId().equals(actorId))throw LibraryException.forbidden("You can cancel only your own reservation");
        if(r.getStatus()!=ReservationStatus.WAITING&&r.getStatus()!=ReservationStatus.READY)throw LibraryException.badRequest("Only active reservations can be cancelled");
        boolean wasReady=r.getStatus()==ReservationStatus.READY;r.setStatus(ReservationStatus.CANCELLED);
        if(wasReady){
            BookCopy reserved=copies.findByStatus(CopyStatus.RESERVED).stream().filter(c->c.getBook().getId().equals(r.getBook().getId())).findFirst().orElse(null);
            if(reserved!=null){reserved.setStatus(CopyStatus.AVAILABLE);processNext(reserved);}
        }
    }
    private void processNext(BookCopy copy){
        reservations.findByStatusOrderByReservationDateAsc(ReservationStatus.WAITING).stream()
            .filter(r->r.getBook().getId().equals(copy.getBook().getId())).findFirst().ifPresent(r->{
                r.setStatus(ReservationStatus.READY);r.setReadyDate(java.time.LocalDate.now());r.setExpiryDate(java.time.LocalDate.now().plusDays(3));copy.setStatus(CopyStatus.RESERVED);
            });
    }
    @org.springframework.scheduling.annotation.Scheduled(fixedDelay=60000)
    @Transactional public void expireReadyReservations(){
        for(Reservation reservation:reservations.findByStatusAndExpiryDateBefore(ReservationStatus.READY,java.time.LocalDate.now())){
            reservation.setStatus(ReservationStatus.EXPIRED);
            BookCopy copy=copies.findByStatus(CopyStatus.RESERVED).stream()
                .filter(c->c.getBook().getId().equals(reservation.getBook().getId())).findFirst().orElse(null);
            if(copy!=null){copy.setStatus(CopyStatus.AVAILABLE);processNext(copy);}
        }
    }
    @Transactional(readOnly=true) public List<Reservation> entities(){return reservations.findAll();}
    @Transactional(readOnly=true) public long pendingCount(){return reservations.countByStatus(ReservationStatus.WAITING);}
}
