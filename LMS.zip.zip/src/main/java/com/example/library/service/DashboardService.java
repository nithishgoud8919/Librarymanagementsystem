package com.example.library.service;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.*;
import com.example.library.repository.*;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class DashboardService {
    private final UserRepository users;private final BookRepository books;private final BookCopyRepository copies;
    private final BorrowService borrowings;private final FineService fines;private final ReservationService reservations;private final UserService userService;
    public DashboardService(UserRepository users,BookRepository books,BookCopyRepository copies,BorrowService borrowings,FineService fines,ReservationService reservations,UserService userService){
        this.users=users;this.books=books;this.copies=copies;this.borrowings=borrowings;this.fines=fines;this.reservations=reservations;this.userService=userService;
    }
    public Map<String,Object> admin(){
        return Map.of("totalUsers",users.count(),"totalLibrarians",users.countByRole_Name("LIBRARIAN"),"totalMembers",users.countByRole_Name("MEMBER"),
            "totalBooks",books.countByStatus(BookStatus.ACTIVE),"totalCopies",copies.count(),"availableCopies",copies.countByStatus(CopyStatus.AVAILABLE),
            "activeBorrowings",borrowings.activeCount(),"overdueBorrowings",borrowings.overdue().size(),"unpaidFines",fines.unpaidCount());
    }
    public Map<String,Object> librarian(){
        List<UserView> recent=users.findAll().stream().filter(u->u.getRole().getName().equals("MEMBER"))
            .sorted(Comparator.comparing(User::getCreatedAt).reversed()).limit(5).map(UserView::from).toList();
        return Map.of("issuedToday",borrowings.issuedToday().size(),"returnedToday",borrowings.returnedToday().size(),
            "overdueBooks",borrowings.overdue().size(),"pendingReservations",reservations.pendingCount(),"recentMembers",recent,
            "availableCopies",copies.countByStatus(CopyStatus.AVAILABLE),"unavailableCopies",copies.count()-copies.countByStatus(CopyStatus.AVAILABLE));
    }
    public Map<String,Object> member(Long id){
        List<BorrowView> memberLoans=borrowings.list(id);
        List<BorrowView> active=memberLoans.stream().filter(t->t.status()==BorrowStatus.ACTIVE||t.status()==BorrowStatus.OVERDUE).toList();
        List<Book> collection=books.findByStatusOrderByTitleAsc(BookStatus.ACTIVE);
        Set<Long> activeBookIds=collection.stream().map(Book::getId).collect(Collectors.toSet());
        Map<Long,List<CollectionCopyView>> collectionCopies=copies.findAll().stream()
            .filter(copy->activeBookIds.contains(copy.getBook().getId()))
            .collect(Collectors.groupingBy(copy->copy.getBook().getId(),
                Collectors.mapping(copy->new CollectionCopyView(copy.getCopyCode(),copy.getShelfLocation()),Collectors.toList())));
        List<CollectionBookView> inventory=collection.stream().map(book->new CollectionBookView(book.getId(),book.getTitle(),book.getAuthor(),
            book.getCategory(),book.getPublisher(),book.getPublicationYear(),copies.countByBook_Id(book.getId()),
            copies.countByBook_IdAndStatus(book.getId(),CopyStatus.AVAILABLE),
            collectionCopies.getOrDefault(book.getId(),List.of()))).toList();
        return Map.of("currentLoans",active,"upcomingDueDates",active.stream().filter(t->!t.dueDate().isBefore(LocalDate.now())).toList(),
            "overdueBooks",active.stream().filter(t->t.dueDate().isBefore(LocalDate.now())).toList(),"outstandingFines",fines.list(id),
            "activeReservations",reservations.list(id).stream().filter(r->r.status()==ReservationStatus.READY||r.status()==ReservationStatus.WAITING).toList(),
            "borrowingHistory",memberLoans,"collection",inventory);
    }
}
