package com.example.library.service;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.*;
import com.example.library.exception.LibraryException;
import com.example.library.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Service
public class BookService {
    private final BookRepository books; private final BookCopyRepository copies;
    public BookService(BookRepository books,BookCopyRepository copies){this.books=books;this.copies=copies;}
    @Transactional(readOnly=true) public Book entity(Long id){return books.findById(id).orElseThrow(()->LibraryException.notFound("Book not found"));}
    @Transactional public Book lockEntity(Long id){return books.lockById(id).orElseThrow(()->LibraryException.notFound("Book not found"));}
    private BookView view(Book b){return new BookView(b.getId(),b.getTitle(),b.getIsbn(),b.getDescription(),b.getAuthor(),b.getCategory(),b.getPublisher(),b.getPublicationYear(),b.getLanguage(),b.getStatus(),copies.countByBook_Id(b.getId()),copies.countByBook_IdAndStatus(b.getId(),CopyStatus.AVAILABLE),b.getCreatedAt());}
    @Transactional(readOnly=true) public List<BookView> list(String keyword,String category,String author){
        String k=blankToNull(keyword),c=blankToNull(category),a=blankToNull(author);
        return books.search(k,c,a).stream().map(this::view).toList();
    }
    public BookView get(Long id){return view(entity(id));}
    @Transactional public BookView create(BookRequest r){
        if(books.existsByIsbnIgnoreCase(r.isbn()))throw LibraryException.conflict("ISBN is already registered");
        return view(books.save(new Book(r.title(),r.isbn(),r.description(),r.author(),r.category(),r.publisher(),r.publicationYear(),r.language())));
    }
    @Transactional public BookView update(Long id,BookRequest r){
        Book b=entity(id);
        if(books.findAll().stream().anyMatch(x->x.getIsbn().equalsIgnoreCase(r.isbn())&&!x.getId().equals(id)))throw LibraryException.conflict("ISBN is already registered");
        b.setTitle(r.title());b.setIsbn(r.isbn());b.setDescription(r.description());b.setAuthor(r.author());b.setCategory(r.category());b.setPublisher(r.publisher());b.setPublicationYear(r.publicationYear());b.setLanguage(r.language());
        return view(b);
    }
    @Transactional public void archive(Long id){entity(id).setStatus(BookStatus.ARCHIVED);}
    private String blankToNull(String s){return s==null||s.isBlank()?null:s.trim();}
}
