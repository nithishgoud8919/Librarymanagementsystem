package com.example.library.service;

import com.example.library.config.CirculationPolicy;
import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.*;
import com.example.library.exception.LibraryException;
import com.example.library.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.*;

@Service
public class FineService {
    private final FineRepository fines;private final PaymentRepository payments;
    public FineService(FineRepository fines,PaymentRepository payments){this.fines=fines;this.payments=payments;}
    private FineView view(Fine f){return new FineView(f.getId(),f.getMember().getId(),f.getMember().getFullName(),f.getBorrowTransaction().getId(),f.getAmount(),f.getPaidAmount(),f.getStatus(),f.getReason(),f.getCreatedAt());}
    @Transactional(readOnly=true) public List<FineView> list(Long memberId){return (memberId==null?fines.findAllByOrderByCreatedAtDesc():fines.findByMember_IdOrderByCreatedAtDesc(memberId)).stream().map(this::view).toList();}
    @Transactional public Fine create(BorrowTransaction transaction,BigDecimal amount,String reason){
        if(amount.signum()<=0)return null;
        return fines.save(new Fine(transaction,transaction.getMember(),amount,reason));
    }
    @Transactional public FineView payment(Long fineId,PaymentRequest request,User recordedBy){
        Fine f=fines.findById(fineId).orElseThrow(()->LibraryException.notFound("Fine not found"));
        if(f.getStatus()==FineStatus.WAIVED||f.getStatus()==FineStatus.PAID)throw LibraryException.badRequest("This fine does not accept further payments");
        BigDecimal remaining=f.getAmount().subtract(f.getPaidAmount());
        if(request.amount().compareTo(remaining)>0)throw LibraryException.badRequest("Payment exceeds the remaining balance");
        f.setPaidAmount(f.getPaidAmount().add(request.amount()));
        f.setStatus(f.getPaidAmount().compareTo(f.getAmount())>=0?FineStatus.PAID:FineStatus.PARTIALLY_PAID);
        payments.save(new Payment(f,request.amount(),recordedBy,request.notes()));
        return view(f);
    }
    @Transactional public FineView waive(Long fineId,String reason){
        Fine f=fines.findById(fineId).orElseThrow(()->LibraryException.notFound("Fine not found"));
        if(f.getStatus()==FineStatus.PAID)throw LibraryException.badRequest("A paid fine cannot be waived");
        f.setStatus(FineStatus.WAIVED);
        if(reason!=null&&!reason.isBlank())f.setReason(f.getReason()+" (waived: "+reason.trim()+")");
        return view(f);
    }
    @Transactional(readOnly=true) public BigDecimal outstanding(Long memberId){
        return fines.findByMember_IdOrderByCreatedAtDesc(memberId).stream()
            .filter(f->f.getStatus()==FineStatus.PENDING||f.getStatus()==FineStatus.PARTIALLY_PAID)
            .map(f->f.getAmount().subtract(f.getPaidAmount())).reduce(BigDecimal.ZERO,BigDecimal::add);
    }
    @Transactional(readOnly=true) public List<Fine> entities(){return fines.findAllByOrderByCreatedAtDesc();}
    @Transactional(readOnly=true) public long unpaidCount(){return fines.countByStatusIn(List.of(FineStatus.PENDING,FineStatus.PARTIALLY_PAID));}
    public BigDecimal seriousLimit(){return CirculationPolicy.SERIOUS_UNPAID_FINE_LIMIT;}
}
