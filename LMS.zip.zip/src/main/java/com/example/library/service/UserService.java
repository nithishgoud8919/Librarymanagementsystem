package com.example.library.service;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.*;
import com.example.library.exception.LibraryException;
import com.example.library.repository.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Service
public class UserService {
    private final UserRepository users; private final RoleRepository roles; private final PasswordEncoder encoder;
    public UserService(UserRepository users,RoleRepository roles,PasswordEncoder encoder){this.users=users;this.roles=roles;this.encoder=encoder;}
    @Transactional(readOnly=true) public User getEntity(Long id){return users.findById(id).orElseThrow(()->LibraryException.notFound("User not found"));}
    @Transactional public User lockEntity(Long id){return users.lockById(id).orElseThrow(()->LibraryException.notFound("User not found"));}
    @Transactional(readOnly=true) public User getByEmail(String email){return users.findByEmailIgnoreCase(email).orElseThrow(()->LibraryException.notFound("User not found"));}
    public UserView get(Long id){return UserView.from(getEntity(id));}
    public List<UserView> search(String keyword,String role){
        String q=keyword==null?"":keyword.trim();
        List<User> results=q.isBlank()?users.findAll():users.findByFullNameContainingIgnoreCaseOrEmailContainingIgnoreCase(q,q);
        return results.stream().filter(u->role==null||u.getRole().getName().equals(role))
                .map(UserView::from).toList();
    }
    @Transactional public UserView create(UserRequest request,String actorRole){
        if(users.existsByEmailIgnoreCase(request.email()))throw LibraryException.conflict("Email is already registered");
        String requested=request.role()==null?"MEMBER":request.role().toUpperCase(Locale.ROOT);
        if(actorRole.equals("LIBRARIAN") && !requested.equals("MEMBER"))throw LibraryException.forbidden("Librarians can create member accounts only");
        if(!Set.of("ADMIN","LIBRARIAN","MEMBER").contains(requested))throw LibraryException.badRequest("Unknown role");
        Role role=roles.findByName(requested).orElseThrow(()->LibraryException.badRequest("Role is not configured"));
        if(request.password()==null||request.password().length()<8)throw LibraryException.badRequest("Password must contain at least 8 characters");
        User user=new User(request.fullName(),request.email().trim().toLowerCase(Locale.ROOT),encoder.encode(request.password()),request.phone(),request.address(),role);
        return UserView.from(users.save(user));
    }
    @Transactional public UserView update(Long id,UserRequest request,String actorRole){
        User user=getEntity(id);
        if(users.findByEmailIgnoreCase(request.email()).filter(u->!u.getId().equals(id)).isPresent())throw LibraryException.conflict("Email is already registered");
        user.setFullName(request.fullName());user.setEmail(request.email().trim().toLowerCase(Locale.ROOT));user.setPhone(request.phone());user.setAddress(request.address());
        if(request.role()!=null && actorRole.equals("ADMIN"))user.setRole(roles.findByName(request.role().toUpperCase(Locale.ROOT)).orElseThrow(()->LibraryException.badRequest("Unknown role")));
        if(request.password()!=null&&!request.password().isBlank())user.setPassword(encoder.encode(request.password()));
        return UserView.from(user);
    }
    @Transactional public UserView changeStatus(Long id,AccountStatus status){User u=getEntity(id);u.setStatus(status);return UserView.from(u);}
    @Transactional public UserView updateProfile(Long id,ProfileRequest request){User u=getEntity(id);u.setFullName(request.fullName());u.setPhone(request.phone());u.setAddress(request.address());return UserView.from(u);}
}
