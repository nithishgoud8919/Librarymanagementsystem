package com.example.library.service;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.*;
import com.example.library.exception.LibraryException;
import com.example.library.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    private final UserRepository users; private final PasswordEncoder encoder;
    public AuthService(UserRepository users,PasswordEncoder encoder){this.users=users;this.encoder=encoder;}
    @Transactional(readOnly=true)
    public UserView login(LoginRequest request,HttpSession session){
        User user=users.findByEmailIgnoreCase(request.email()).orElseThrow(()->LibraryException.forbidden("Invalid email or password"));
        if(user.getStatus()!=AccountStatus.ACTIVE || !encoder.matches(request.password(),user.getPassword()))
            throw LibraryException.forbidden("Invalid email or password or inactive account");
        session.setAttribute("userId",user.getId());
        return UserView.from(user);
    }
    public void logout(HttpSession session){if(session!=null)session.invalidate();}
}
