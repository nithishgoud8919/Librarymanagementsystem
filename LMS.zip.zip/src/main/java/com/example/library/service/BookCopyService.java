package com.example.library.service;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.*;
import com.example.library.exception.LibraryException;
import com.example.library.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Service
public class BookCopyService {
    private final BookCopyRepository copies;private final BookService books;
    public BookCopyService(BookCopyRepository copies,BookService books){this.copies=copies;this.books=books;}
    private CopyView view(BookCopy c){return new CopyView(c.getId(),c.getBook().getId(),c.getBook().getTitle(),c.getCopyCode(),c.getShelfLocation(),c.getCondition(),c.getStatus());}
    @Transactional(readOnly=true) public List<CopyView> list(Long bookId){books.entity(bookId);return copies.findByBook_IdOrderByCopyCode(bookId).stream().map(this::view).toList();}
    @Transactional public CopyView create(Long bookId,CopyRequest r){
        Book book=books.lockEntity(bookId);
        if(copies.existsByCopyCodeIgnoreCase(r.copyCode()))throw LibraryException.conflict("Copy code is already registered");
        return view(copies.save(new BookCopy(book,r.copyCode(),r.shelfLocation(),r.condition()==null?CopyCondition.GOOD:r.condition())));
    }
    @Transactional public List<CopyView> createBatch(Long bookId,CopyBatchRequest request){
        Book book=books.lockEntity(bookId);
        List<BookCopy> existingCopies=copies.findByBook_IdOrderByCopyCode(bookId);
        Set<Integer> usedSequences=new HashSet<>();
        for(BookCopy copy:existingCopies){
            String prefix="BK"+bookId+"-";
            String code=copy.getCopyCode();
            if(code.startsWith(prefix)){
                try{usedSequences.add(Integer.parseInt(code.substring(prefix.length())));}
                catch(NumberFormatException ignored){}
            }
        }
        List<BookCopy> created=new ArrayList<>(request.quantity());
        int sequence=1;
        while(created.size()<request.quantity()){
            String code=String.format(Locale.ROOT,"BK%d-%03d",bookId,sequence++);
            if(usedSequences.contains(sequence-1)||copies.existsByCopyCodeIgnoreCase(code))continue;
            usedSequences.add(sequence-1);
            created.add(new BookCopy(book,code,request.shelfLocation(),
                request.condition()==null?CopyCondition.GOOD:request.condition()));
        }
        return copies.saveAll(created).stream().map(this::view).toList();
    }
    @Transactional public CopyView update(Long id,CopyUpdate r){
        BookCopy c=entity(id);c.setShelfLocation(r.shelfLocation());c.setCondition(r.condition());
        if((r.condition()==CopyCondition.DAMAGED||r.condition()==CopyCondition.POOR)&&c.getStatus()==CopyStatus.AVAILABLE)c.setStatus(CopyStatus.DAMAGED);
        return view(c);
    }
    @Transactional public CopyView status(Long id,CopyStatus status){
        BookCopy c=entity(id);
        if(status==CopyStatus.BORROWED||status==CopyStatus.RESERVED)throw LibraryException.badRequest("Borrowed and reserved statuses are managed by circulation workflows");
        if(c.getStatus()==CopyStatus.BORROWED||c.getStatus()==CopyStatus.RESERVED)throw LibraryException.badRequest("An active borrowing or reservation cannot be changed manually");
        if(status==CopyStatus.AVAILABLE&&(c.getCondition()==CopyCondition.DAMAGED||c.getCondition()==CopyCondition.POOR))throw LibraryException.badRequest("Repair the copy condition before making it available");
        c.setStatus(status);return view(c);
    }
    @Transactional(readOnly=true) public BookCopy entity(Long id){return copies.findById(id).orElseThrow(()->LibraryException.notFound("Book copy not found"));}
    @Transactional public BookCopy lockEntity(Long id){return copies.lockById(id).orElseThrow(()->LibraryException.notFound("Book copy not found"));}
    public List<CopyView> all(){return copies.findAll().stream().map(this::view).toList();}
}
