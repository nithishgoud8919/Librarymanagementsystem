package com.example.library.service;

import com.example.library.config.CirculationPolicy;
import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.*;
import com.example.library.exception.LibraryException;
import com.example.library.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Service
public class BorrowService {
    private final BorrowTransactionRepository borrowings;private final UserService users;private final BookCopyService copies;
    private final FineService fines;private final ReservationRepository reservations;private final BookCopyRepository copyRepository;
    public BorrowService(BorrowTransactionRepository borrowings,UserService users,BookCopyService copies,FineService fines,ReservationRepository reservations,BookCopyRepository copyRepository){
        this.borrowings=borrowings;this.users=users;this.copies=copies;this.fines=fines;this.reservations=reservations;this.copyRepository=copyRepository;
    }
    private BorrowView view(BorrowTransaction t){return new BorrowView(t.getId(),t.getMember().getId(),t.getMember().getFullName(),t.getBookCopy().getId(),t.getBookCopy().getCopyCode(),t.getBookCopy().getBook().getId(),t.getBookCopy().getBook().getTitle(),t.getIssueDate(),t.getDueDate(),t.getReturnDate(),t.getStatus(),t.getIssuedBy().getFullName(),t.getReturnedBy()==null?null:t.getReturnedBy().getFullName());}
    @Transactional(readOnly=true) public List<BorrowView> list(Long memberId){
        return (memberId==null?borrowings.findAll():borrowings.findByMember_IdOrderByIssueDateDesc(memberId)).stream().map(this::view).toList();
    }
    @Transactional(readOnly=true) public BorrowView get(Long id){return view(borrowings.findById(id).orElseThrow(()->LibraryException.notFound("Borrowing transaction not found")));}
    @Transactional public BorrowView issue(BorrowRequest request,User issuer){
        User member=users.lockEntity(request.memberId());
        if(!member.getRole().getName().equals("MEMBER")||member.getStatus()!=AccountStatus.ACTIVE)throw LibraryException.badRequest("Borrowing requires an active member account");
        if(borrowings.countByMember_IdAndStatusIn(member.getId(),List.of(BorrowStatus.ACTIVE,BorrowStatus.OVERDUE))>=CirculationPolicy.MAX_ACTIVE_BOOKS)
            throw LibraryException.badRequest("Member has reached the limit of "+CirculationPolicy.MAX_ACTIVE_BOOKS+" active books");
        if(fines.outstanding(member.getId()).compareTo(CirculationPolicy.SERIOUS_UNPAID_FINE_LIMIT)>=0)
            throw LibraryException.badRequest("Member has serious unpaid fines and cannot borrow");
        BookCopy copy=copies.lockEntity(request.copyId());
        if(copy.getBook().getStatus()!=BookStatus.ACTIVE)throw LibraryException.badRequest("Archived books cannot be issued");
        if(copy.getStatus()==CopyStatus.RESERVED){
            Reservation ready=reservations.findByStatusOrderByReservationDateAsc(ReservationStatus.READY).stream()
                    .filter(r->r.getBook().getId().equals(copy.getBook().getId())).findFirst()
                    .orElseThrow(()->LibraryException.badRequest("This copy is reserved"));
            if(!ready.getMember().getId().equals(member.getId()))throw LibraryException.badRequest("This copy is reserved for the next member in the queue");
            ready.setStatus(ReservationStatus.FULFILLED);
        } else if(copy.getStatus()!=CopyStatus.AVAILABLE) throw LibraryException.badRequest("Book copy is unavailable");
        LocalDate issueDate=request.issueDate()==null?LocalDate.now():request.issueDate();
        BorrowTransaction t=borrowings.save(new BorrowTransaction(member,copy,issueDate,issueDate.plusDays(CirculationPolicy.BORROWING_DAYS),issuer));
        copy.setStatus(CopyStatus.BORROWED);
        return view(t);
    }
    @Transactional public BorrowView returnBook(Long id,ReturnRequest request,User returnedBy){
        BorrowTransaction t=borrowings.findById(id).orElseThrow(()->LibraryException.notFound("Borrowing transaction not found"));
        if(t.getStatus()!=BorrowStatus.ACTIVE&&t.getStatus()!=BorrowStatus.OVERDUE)throw LibraryException.badRequest("Only an active borrowing can be returned");
        BookCopy copy=t.getBookCopy();LocalDate today=LocalDate.now();
        t.setReturnDate(today);t.setReturnedBy(returnedBy);
        if(request.lost()){
            t.setStatus(BorrowStatus.LOST);copy.setStatus(CopyStatus.LOST);
            fines.create(t,CirculationPolicy.LOST_COPY_FEE,"Lost book replacement fee");
        } else {
            t.setStatus(BorrowStatus.RETURNED);copy.setCondition(request.condition());
            if(request.condition()==CopyCondition.DAMAGED||request.condition()==CopyCondition.POOR)copy.setStatus(CopyStatus.DAMAGED);
            else {copy.setStatus(CopyStatus.AVAILABLE);processReservation(copy);}
            long overdueDays=Math.max(0,java.time.temporal.ChronoUnit.DAYS.between(t.getDueDate(),today));
            if(overdueDays>0)fines.create(t,CirculationPolicy.DAILY_FINE_RATE.multiply(BigDecimal.valueOf(overdueDays)),"Overdue return: "+overdueDays+" days");
        }
        return view(t);
    }
    private void processReservation(BookCopy returned){
        LocalDate today=LocalDate.now();
        List<Reservation> queue=reservations.findByStatusOrderByReservationDateAsc(ReservationStatus.WAITING);
        for(Reservation r:queue){
            if(!r.getBook().getId().equals(returned.getBook().getId()))continue;
            r.setStatus(ReservationStatus.READY);r.setReadyDate(today);r.setExpiryDate(today.plusDays(CirculationPolicy.RESERVATION_HOLD_DAYS));
            returned.setStatus(CopyStatus.RESERVED);return;
        }
    }
    @Transactional(readOnly=true) public List<BorrowView> overdue(){return borrowings.findOverdue(LocalDate.now()).stream().map(this::view).toList();}
    @Transactional(readOnly=true) public List<BorrowView> active(){return borrowings.findActive().stream().map(this::view).toList();}
    @Transactional(readOnly=true) public List<BorrowView> issuedToday(){return borrowings.findByIssueDate(LocalDate.now()).stream().map(this::view).toList();}
    @Transactional(readOnly=true) public List<BorrowView> returnedToday(){return borrowings.findByReturnDate(LocalDate.now()).stream().map(this::view).toList();}
    @Transactional(readOnly=true) public long activeCount(){return borrowings.countByStatusIn(List.of(BorrowStatus.ACTIVE,BorrowStatus.OVERDUE));}
}
