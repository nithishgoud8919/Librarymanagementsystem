package com.example.library.service;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.*;
import com.example.library.repository.*;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ReportService {
    private final BookRepository books;private final BookCopyService copies;private final BorrowService borrowings;private final BorrowTransactionRepository transactions;
    private final FineService fines;private final ReservationService reservations;
    public ReportService(BookRepository books,BookCopyService copies,BorrowService borrowings,BorrowTransactionRepository transactions,FineService fines,ReservationService reservations){
        this.books=books;this.copies=copies;this.borrowings=borrowings;this.transactions=transactions;this.fines=fines;this.reservations=reservations;
    }
    public Map<String,Object> inventory(){return Map.of("books",books.findAll().stream().map(b->Map.of("id",b.getId(),"title",b.getTitle(),"author",b.getAuthor(),"category",b.getCategory(),"status",b.getStatus(),"copies",copies.list(b.getId()))).toList());}
    public Map<String,Object> borrowingReport(){return Map.of("borrowings",borrowings.active());}
    public Map<String,Object> overdueReport(){return Map.of("borrowings",borrowings.overdue());}
    public Map<String,Object> fineReport(){return Map.of("fines",fines.list(null));}
    public Map<String,Object> popular(){
        List<Map<String,Object>> rows=transactions.mostBorrowed(PageRequest.of(0,10)).stream().map(r->Map.<String,Object>of("bookId",r[0],"title",r[1],"author",r[2],"borrowCount",r[3])).toList();
        return Map.of("books",rows);
    }
    public Map<String,Object> memberHistory(Long memberId){return Map.of("borrowings",borrowings.list(memberId));}
    public Map<String,Object> byCategory(){
        List<Map<String,Object>> rows=books.countByCategory().stream().map(r->Map.<String,Object>of("category",r[0],"bookCount",r[1])).toList();
        return Map.of("categories",rows);
    }
}
