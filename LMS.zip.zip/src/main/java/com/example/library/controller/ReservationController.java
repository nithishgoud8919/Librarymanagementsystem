package com.example.library.controller;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.User;
import com.example.library.service.*;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {
    private final ReservationService reservations;private final UserService users;
    public ReservationController(ReservationService reservations,UserService users){this.reservations=reservations;this.users=users;}
    @GetMapping @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')") public List<ReservationView> list(){return reservations.list(null);}
    @GetMapping("/mine") @PreAuthorize("hasRole('MEMBER')") public List<ReservationView> mine(@AuthenticationPrincipal UserDetails principal){return reservations.list(users.getByEmail(principal.getUsername()).getId());}
    @PostMapping @PreAuthorize("hasRole('MEMBER')") public ReservationView create(@Valid @RequestBody ReservationRequest request,@AuthenticationPrincipal UserDetails principal){
        return reservations.create(users.getByEmail(principal.getUsername()).getId(),request.bookId());
    }
    @DeleteMapping("/{id}") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN','MEMBER')")
    public Message delete(@PathVariable Long id,@AuthenticationPrincipal UserDetails principal){
        User actor=users.getByEmail(principal.getUsername());reservations.cancel(id,actor.getId(),!actor.getRole().getName().equals("MEMBER"));return new Message("Reservation cancelled");
    }
    @PatchMapping("/{id}/cancel") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN','MEMBER')")
    public Message cancel(@PathVariable Long id,@AuthenticationPrincipal UserDetails principal){
        User actor=users.getByEmail(principal.getUsername());reservations.cancel(id,actor.getId(),!actor.getRole().getName().equals("MEMBER"));return new Message("Reservation cancelled");
    }
}
