package com.example.library.controller;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.User;
import com.example.library.service.*;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;private final UserService users;
    public AuthController(AuthService auth,UserService users){this.auth=auth;this.users=users;}
    @PostMapping("/login") public UserView login(@Valid @RequestBody LoginRequest request,HttpSession session){return auth.login(request,session);}
    @PostMapping("/logout") public Message logout(HttpSession session){auth.logout(session);return new Message("Logged out");}
    @GetMapping("/me") public UserView me(@AuthenticationPrincipal UserDetails principal){return UserView.from(users.getByEmail(principal.getUsername()));}
}
