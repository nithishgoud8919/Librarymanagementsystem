package com.example.library.controller;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.User;
import com.example.library.exception.LibraryException;
import com.example.library.service.*;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/fines")
public class FineController {
    private final FineService fines;private final UserService users;
    public FineController(FineService fines,UserService users){this.fines=fines;this.users=users;}
    @GetMapping @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')") public List<FineView> list(){return fines.list(null);}
    @GetMapping("/mine") @PreAuthorize("hasRole('MEMBER')") public List<FineView> mine(@AuthenticationPrincipal UserDetails principal){return fines.list(users.getByEmail(principal.getUsername()).getId());}
    @PostMapping("/{id}/payment") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
    public FineView payment(@PathVariable Long id,@Valid @RequestBody PaymentRequest request,@AuthenticationPrincipal UserDetails principal){return fines.payment(id,request,users.getByEmail(principal.getUsername()));}
    @PostMapping("/{id}/waive") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
    public FineView waive(@PathVariable Long id,@RequestBody(required=false) WaiveRequest request){return fines.waive(id,request==null?"Waived by staff":request.reason());}
}
