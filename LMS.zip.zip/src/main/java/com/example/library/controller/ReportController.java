package com.example.library.controller;

import com.example.library.entity.User;
import com.example.library.exception.LibraryException;
import com.example.library.service.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/reports")
@PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
public class ReportController {
    private final ReportService reports;private final UserService users;
    public ReportController(ReportService reports,UserService users){this.reports=reports;this.users=users;}
    @GetMapping("/inventory") public Map<String,Object> inventory(){return reports.inventory();}
    @GetMapping("/borrowings") public Map<String,Object> borrowings(){return reports.borrowingReport();}
    @GetMapping("/overdue") public Map<String,Object> overdue(){return reports.overdueReport();}
    @GetMapping("/fines") public Map<String,Object> fines(){return reports.fineReport();}
    @GetMapping("/most-borrowed") public Map<String,Object> mostBorrowed(){return reports.popular();}
    @GetMapping("/member-history") public Map<String,Object> memberHistory(@RequestParam Long memberId){return reports.memberHistory(memberId);}
    @GetMapping("/categories") public Map<String,Object> categories(){return reports.byCategory();}
}
