package com.example.library.controller;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.User;
import com.example.library.exception.LibraryException;
import com.example.library.service.*;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/borrowings")
public class BorrowController {
    private final BorrowService borrowings;private final UserService users;
    public BorrowController(BorrowService borrowings,UserService users){this.borrowings=borrowings;this.users=users;}
    @GetMapping @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')") public List<BorrowView> list(){return borrowings.list(null);}
    @GetMapping("/{id}") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN','MEMBER')")
    public BorrowView get(@PathVariable Long id,@AuthenticationPrincipal UserDetails principal){
        BorrowView tx=borrowings.get(id);User actor=users.getByEmail(principal.getUsername());
        if(actor.getRole().getName().equals("MEMBER")&&!actor.getId().equals(tx.memberId()))throw LibraryException.forbidden("Members may view only their own borrowing history");
        return tx;
    }
    @PostMapping @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
    public BorrowView issue(@Valid @RequestBody BorrowRequest request,@AuthenticationPrincipal UserDetails principal){return borrowings.issue(request,users.getByEmail(principal.getUsername()));}
    @PostMapping("/{id}/return") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
    public BorrowView returnBook(@PathVariable Long id,@Valid @RequestBody ReturnRequest request,@AuthenticationPrincipal UserDetails principal){return borrowings.returnBook(id,request,users.getByEmail(principal.getUsername()));}
    @GetMapping("/overdue") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')") public List<BorrowView> overdue(){return borrowings.overdue();}
}
