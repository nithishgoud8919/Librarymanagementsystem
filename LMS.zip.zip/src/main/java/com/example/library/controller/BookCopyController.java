package com.example.library.controller;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.CopyStatus;
import com.example.library.service.*;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
public class BookCopyController {
    private final BookCopyService copies;
    public BookCopyController(BookCopyService copies){this.copies=copies;}
    @GetMapping("/api/books/{bookId}/copies") public List<CopyView> list(@PathVariable Long bookId){return copies.list(bookId);}
    @PostMapping("/api/books/{bookId}/copies") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
    public CopyView create(@PathVariable Long bookId,@Valid @RequestBody CopyRequest request){return copies.create(bookId,request);}
    @PostMapping("/api/books/{bookId}/copies/batch") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
    public List<CopyView> createBatch(@PathVariable Long bookId,@Valid @RequestBody CopyBatchRequest request){return copies.createBatch(bookId,request);}
    @GetMapping("/api/copies") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')") public List<CopyView> all(){return copies.all();}
    @PutMapping("/api/copies/{id}") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
    public CopyView update(@PathVariable Long id,@Valid @RequestBody CopyUpdate request){return copies.update(id,request);}
    @PatchMapping("/api/copies/{id}/status") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
    public CopyView status(@PathVariable Long id,@Valid @RequestBody CopyStatusRequest request){return copies.status(id,request.status());}
}
