package com.example.library.controller;

import com.example.library.dto.ApiDtos.BorrowView;
import com.example.library.entity.User;
import com.example.library.exception.LibraryException;
import com.example.library.service.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
public class UserBorrowingController {
    private final BorrowService borrowings;private final UserService users;
    public UserBorrowingController(BorrowService borrowings,UserService users){this.borrowings=borrowings;this.users=users;}
    @GetMapping("/api/users/{userId}/borrowings") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN','MEMBER')")
    public List<BorrowView> list(@PathVariable Long userId,@AuthenticationPrincipal UserDetails principal){
        User actor=users.getByEmail(principal.getUsername());
        if(actor.getRole().getName().equals("MEMBER")&&!actor.getId().equals(userId))throw LibraryException.forbidden("Members may view only their own borrowing history");
        return borrowings.list(userId);
    }
}
