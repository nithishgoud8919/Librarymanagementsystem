package com.example.library.controller;

import com.example.library.dto.ApiDtos.*;
import com.example.library.service.BookService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/books")
public class BookController {
    private final BookService books;
    public BookController(BookService books){this.books=books;}
    @GetMapping public List<BookView> list(@RequestParam(required=false) String keyword,@RequestParam(required=false) String category,@RequestParam(required=false) String author){return books.list(keyword,category,author);}
    @GetMapping("/search") public List<BookView> search(@RequestParam(required=false) String keyword){return books.list(keyword,null,null);}
    @GetMapping("/{id}") public BookView get(@PathVariable Long id){return books.get(id);}
    @PostMapping @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')") public BookView create(@Valid @RequestBody BookRequest request){return books.create(request);}
    @PutMapping("/{id}") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')") public BookView update(@PathVariable Long id,@Valid @RequestBody BookRequest request){return books.update(id,request);}
    @PatchMapping("/{id}/archive") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')") public Message archive(@PathVariable Long id){books.archive(id);return new Message("Book archived");}
}
