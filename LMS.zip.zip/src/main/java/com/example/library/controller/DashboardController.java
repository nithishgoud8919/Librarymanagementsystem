package com.example.library.controller;

import com.example.library.service.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {
    private final DashboardService dashboards;private final UserService users;
    public DashboardController(DashboardService dashboards,UserService users){this.dashboards=dashboards;this.users=users;}
    @GetMapping("/admin") @PreAuthorize("hasRole('ADMIN')") public Map<String,Object> admin(){return dashboards.admin();}
    @GetMapping("/librarian") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')") public Map<String,Object> librarian(){return dashboards.librarian();}
    @GetMapping("/member") @PreAuthorize("hasRole('MEMBER')") public Map<String,Object> member(@AuthenticationPrincipal UserDetails principal){return dashboards.member(users.getByEmail(principal.getUsername()).getId());}
}
