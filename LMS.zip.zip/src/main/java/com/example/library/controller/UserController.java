package com.example.library.controller;

import com.example.library.dto.ApiDtos.*;
import com.example.library.entity.User;
import com.example.library.exception.LibraryException;
import com.example.library.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserService users;
    public UserController(UserService users){this.users=users;}
    @GetMapping @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
    public List<UserView> list(@RequestParam(required=false) String keyword,@RequestParam(required=false) String role,@AuthenticationPrincipal UserDetails principal){
        User actor=users.getByEmail(principal.getUsername());
        return users.search(keyword,actor.getRole().getName().equals("LIBRARIAN")?"MEMBER":role);
    }
    @GetMapping("/{id}") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN','MEMBER')")
    public UserView get(@PathVariable Long id,@AuthenticationPrincipal UserDetails principal){
        User actor=users.getByEmail(principal.getUsername());
        if(actor.getRole().getName().equals("MEMBER")&&!actor.getId().equals(id))throw LibraryException.forbidden("Members may view only their own profile");
        return users.get(id);
    }
    @PostMapping @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
    public UserView create(@Valid @RequestBody UserRequest request,@AuthenticationPrincipal UserDetails principal){return users.create(request,users.getByEmail(principal.getUsername()).getRole().getName());}
    @PutMapping("/{id}") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN')")
    public UserView update(@PathVariable Long id,@Valid @RequestBody UserRequest request,@AuthenticationPrincipal UserDetails principal){
        User actor=users.getByEmail(principal.getUsername());
        if(actor.getRole().getName().equals("LIBRARIAN")){
            if(!users.getEntity(id).getRole().getName().equals("MEMBER")||request.role()!=null)throw LibraryException.forbidden("Librarians may update member details only");
        }
        return users.update(id,request,actor.getRole().getName());
    }
    @PatchMapping("/{id}/status") @PreAuthorize("hasRole('ADMIN')")
    public UserView status(@PathVariable Long id,@Valid @RequestBody StatusRequest request){return users.changeStatus(id,request.status());}
    @PutMapping("/{id}/profile") @PreAuthorize("hasAnyRole('ADMIN','LIBRARIAN','MEMBER')")
    public UserView profile(@PathVariable Long id,@Valid @RequestBody ProfileRequest request,@AuthenticationPrincipal UserDetails principal){
        if(!users.getByEmail(principal.getUsername()).getId().equals(id))throw LibraryException.forbidden("You may update only your own profile");
        return users.updateProfile(id,request);
    }
}
