package com.example.library.exception;
import org.springframework.http.HttpStatus;
public class LibraryException extends RuntimeException {
    private final HttpStatus status;
    public LibraryException(HttpStatus status,String message){super(message);this.status=status;}
    public HttpStatus getStatus(){return status;}
    public static LibraryException notFound(String message){return new LibraryException(HttpStatus.NOT_FOUND,message);}
    public static LibraryException badRequest(String message){return new LibraryException(HttpStatus.BAD_REQUEST,message);}
    public static LibraryException conflict(String message){return new LibraryException(HttpStatus.CONFLICT,message);}
    public static LibraryException forbidden(String message){return new LibraryException(HttpStatus.FORBIDDEN,message);}
}
