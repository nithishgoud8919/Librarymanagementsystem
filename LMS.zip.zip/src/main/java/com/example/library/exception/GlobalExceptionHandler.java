package com.example.library.exception;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.*;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.*;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(LibraryException.class)
    ResponseEntity<Map<String,Object>> library(LibraryException ex){return response(ex.getStatus(),ex.getMessage());}
    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<Map<String,Object>> validation(MethodArgumentNotValidException ex){
        String message=ex.getBindingResult().getFieldErrors().stream().map(e->e.getField()+": "+e.getDefaultMessage()).findFirst().orElse("Invalid request");
        return response(HttpStatus.BAD_REQUEST,message);
    }
    @ExceptionHandler(DataIntegrityViolationException.class)
    ResponseEntity<Map<String,Object>> duplicate(DataIntegrityViolationException ex){return response(HttpStatus.CONFLICT,"A record with the same unique value already exists");}
    @ExceptionHandler(AccessDeniedException.class)
    ResponseEntity<Map<String,Object>> forbidden(AccessDeniedException ex){return response(HttpStatus.FORBIDDEN,"You do not have permission to perform this operation");}
    private ResponseEntity<Map<String,Object>> response(HttpStatus status,String message){
        return ResponseEntity.status(status).body(Map.of("timestamp",Instant.now().toString(),"status",status.value(),"error",message));
    }
}
