package com.example.library.dto;

import com.example.library.entity.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.*;

public final class ApiDtos {
    private ApiDtos() {}
    public record LoginRequest(@NotBlank @Email String email,@NotBlank String password) {}
    public record UserRequest(@NotBlank @Size(max=120) String fullName,@NotBlank @Email String email,
                              @Size(min=8,max=100) String password,@Size(max=32) String phone,@Size(max=500) String address,String role) {}
    public record ProfileRequest(@NotBlank @Size(max=120) String fullName,@Size(max=32) String phone,@Size(max=500) String address) {}
    public record StatusRequest(@NotNull AccountStatus status) {}
    public record UserView(Long id,String fullName,String email,String phone,String address,String role,AccountStatus status,LocalDateTime createdAt) {
        public static UserView from(User u){return new UserView(u.getId(),u.getFullName(),u.getEmail(),u.getPhone(),u.getAddress(),u.getRole().getName(),u.getStatus(),u.getCreatedAt());}
    }
    public record BookRequest(@NotBlank @Size(max=240) String title,@NotBlank @Size(max=32) String isbn,@Size(max=3000) String description,
                              @NotBlank @Size(max=160) String author,@NotBlank @Size(max=100) String category,@Size(max=160) String publisher,
                              @Min(1000) @Max(2100) Integer publicationYear,@Size(max=80) String language) {}
    public record BookView(Long id,String title,String isbn,String description,String author,String category,String publisher,Integer publicationYear,String language,
                           BookStatus status,long totalCopies,long availableCopies,LocalDateTime createdAt) {}
    public record CollectionCopyView(String copyCode,String shelfLocation) {}
    public record CollectionBookView(Long id,String title,String author,String category,String publisher,Integer publicationYear,
                                     long totalCopies,long availableCopies,java.util.List<CollectionCopyView> copies) {}
    public record CopyRequest(@NotBlank @Size(max=80) String copyCode,@Size(max=80) String shelfLocation,CopyCondition condition) {}
    public record CopyBatchRequest(@Min(1) @Max(100) int quantity,@Size(max=80) String shelfLocation,CopyCondition condition) {}
    public record CopyUpdate(@NotBlank @Size(max=80) String shelfLocation,@NotNull CopyCondition condition) {}
    public record CopyStatusRequest(@NotNull CopyStatus status) {}
    public record CopyView(Long id,Long bookId,String bookTitle,String copyCode,String shelfLocation,CopyCondition condition,CopyStatus status) {}
    public record BorrowRequest(@NotNull Long memberId,@NotNull Long copyId,@PastOrPresent LocalDate issueDate) {}
    public record ReturnRequest(@NotNull CopyCondition condition,boolean lost) {}
    public record BorrowView(Long id,Long memberId,String memberName,Long copyId,String copyCode,Long bookId,String bookTitle,
                             LocalDate issueDate,LocalDate dueDate,LocalDate returnDate,BorrowStatus status,String issuedBy,String returnedBy) {}
    public record ReservationRequest(@NotNull Long bookId) {}
    public record ReservationView(Long id,Long memberId,String memberName,Long bookId,String bookTitle,LocalDate reservationDate,
                                  LocalDate readyDate,LocalDate expiryDate,ReservationStatus status) {}
    public record PaymentRequest(@NotNull @DecimalMin("0.01") BigDecimal amount,@Size(max=300) String notes) {}
    public record WaiveRequest(@Size(max=300) String reason) {}
    public record FineView(Long id,Long memberId,String memberName,Long transactionId,BigDecimal amount,BigDecimal paidAmount,
                           FineStatus status,String reason,LocalDateTime createdAt) {}
    public record Message(String message) {}
}
