package com.example.library.security;

import com.example.library.entity.*;
import com.example.library.repository.UserRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.List;

public class SessionAuthenticationFilter extends OncePerRequestFilter {
    private final UserRepository users;
    public SessionAuthenticationFilter(UserRepository users){this.users=users;}
    @Override protected void doFilterInternal(HttpServletRequest request,HttpServletResponse response,FilterChain chain) throws ServletException,IOException {
        HttpSession session=request.getSession(false);
        if(session!=null && SecurityContextHolder.getContext().getAuthentication()==null){
            Object value=session.getAttribute("userId");
            if(value instanceof Long id){
                User user=users.findById(id).orElse(null);
                if(user!=null && user.getStatus()==AccountStatus.ACTIVE){
                    var principal=org.springframework.security.core.userdetails.User.withUsername(user.getEmail()).password("").authorities(List.of(new SimpleGrantedAuthority("ROLE_"+user.getRole().getName()))).build();
                    var auth=new UsernamePasswordAuthenticationToken(principal,null,principal.getAuthorities());
                    SecurityContextHolder.getContext().setAuthentication(auth);
                } else session.invalidate();
            }
        }
        chain.doFilter(request,response);
    }
}
