package com.example.library.repository;
import com.example.library.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;
import java.util.*;
public interface BookRepository extends JpaRepository<Book,Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select b from Book b where b.id=:id")
    Optional<Book> lockById(@Param("id") Long id);
    boolean existsByIsbnIgnoreCase(String isbn);
    @Query("select b from Book b where b.status = com.example.library.entity.BookStatus.ACTIVE and (:keyword is null or lower(b.title) like lower(concat('%',:keyword,'%')) or lower(b.author) like lower(concat('%',:keyword,'%')) or lower(b.isbn) like lower(concat('%',:keyword,'%')) or lower(b.category) like lower(concat('%',:keyword,'%')) or lower(coalesce(b.publisher,'')) like lower(concat('%',:keyword,'%'))) and (:category is null or lower(b.category)=lower(:category)) and (:author is null or lower(b.author) like lower(concat('%',:author,'%')))")
    List<Book> search(@Param("keyword") String keyword,@Param("category") String category,@Param("author") String author);
    List<Book> findByStatusOrderByTitleAsc(com.example.library.entity.BookStatus status);
    long countByStatus(com.example.library.entity.BookStatus status);
    @Query("select b.category, count(b) from Book b where b.status = com.example.library.entity.BookStatus.ACTIVE group by b.category")
    List<Object[]> countByCategory();
}
