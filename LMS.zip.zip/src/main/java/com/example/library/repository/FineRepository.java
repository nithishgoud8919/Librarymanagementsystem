package com.example.library.repository;
import com.example.library.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface FineRepository extends JpaRepository<Fine,Long> {
    List<Fine> findByMember_IdOrderByCreatedAtDesc(Long memberId);
    List<Fine> findAllByOrderByCreatedAtDesc();
    long countByStatusIn(Collection<FineStatus> statuses);
    Optional<Fine> findByBorrowTransaction_Id(Long transactionId);
}
