package com.example.library.repository;
import com.example.library.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;
import java.util.*;
public interface UserRepository extends JpaRepository<User,Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select u from User u where u.id=:id")
    Optional<User> lockById(@Param("id") Long id);
    Optional<User> findByEmailIgnoreCase(String email);
    boolean existsByEmailIgnoreCase(String email);
    List<User> findByRole_NameAndFullNameContainingIgnoreCaseOrRole_NameAndEmailContainingIgnoreCase(String role1,String name,String role2,String email);
    List<User> findByFullNameContainingIgnoreCaseOrEmailContainingIgnoreCase(String name,String email);
    long countByRole_Name(String roleName);
}
