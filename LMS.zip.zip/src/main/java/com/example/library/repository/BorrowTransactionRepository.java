package com.example.library.repository;
import com.example.library.entity.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.data.domain.Pageable;
import java.time.LocalDate;
import java.util.*;
public interface BorrowTransactionRepository extends JpaRepository<BorrowTransaction,Long> {
    long countByMember_IdAndStatusIn(Long memberId,Collection<BorrowStatus> statuses);
    List<BorrowTransaction> findByMember_IdOrderByIssueDateDesc(Long memberId);
    List<BorrowTransaction> findByStatusInOrderByDueDateAsc(Collection<BorrowStatus> statuses);
    List<BorrowTransaction> findByIssueDate(LocalDate issueDate);
    List<BorrowTransaction> findByReturnDate(LocalDate returnDate);
    long countByStatusIn(Collection<BorrowStatus> statuses);
    @Query("select t from BorrowTransaction t where t.status in (com.example.library.entity.BorrowStatus.ACTIVE,com.example.library.entity.BorrowStatus.OVERDUE) and t.dueDate < :today order by t.dueDate")
    List<BorrowTransaction> findOverdue(@Param("today") LocalDate today);
    @Query("select t.bookCopy.book.id,t.bookCopy.book.title,t.bookCopy.book.author,count(t) from BorrowTransaction t group by t.bookCopy.book.id,t.bookCopy.book.title,t.bookCopy.book.author order by count(t) desc")
    List<Object[]> mostBorrowed(Pageable pageable);
    @Query("select t from BorrowTransaction t where t.status in (com.example.library.entity.BorrowStatus.ACTIVE,com.example.library.entity.BorrowStatus.OVERDUE) order by t.dueDate")
    List<BorrowTransaction> findActive();
}
