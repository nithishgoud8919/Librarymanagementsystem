package com.example.library.repository;
import com.example.library.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.repository.query.Param;
import java.util.*;
import jakarta.persistence.LockModeType;
public interface BookCopyRepository extends JpaRepository<BookCopy,Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select c from BookCopy c where c.id=:id")
    Optional<BookCopy> lockById(@Param("id") Long id);
    boolean existsByCopyCodeIgnoreCase(String copyCode);
    List<BookCopy> findByBook_IdOrderByCopyCode(Long bookId);
    List<BookCopy> findByStatus(CopyStatus status);
    long countByStatus(CopyStatus status);
    long countByBook_Id(Long bookId);
    long countByBook_IdAndStatus(Long bookId,CopyStatus status);
    @Query("select c.status, count(c) from BookCopy c group by c.status") List<Object[]> countByStatusGrouped();
}
