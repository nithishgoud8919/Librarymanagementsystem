package com.example.library.repository;
import com.example.library.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface ReservationRepository extends JpaRepository<Reservation,Long> {
    boolean existsByMember_IdAndBook_IdAndStatusIn(Long memberId,Long bookId,Collection<ReservationStatus> statuses);
    List<Reservation> findByStatusOrderByReservationDateAsc(ReservationStatus status);
    List<Reservation> findAllByOrderByReservationDateAsc();
    List<Reservation> findByStatusAndExpiryDateBefore(ReservationStatus status,java.time.LocalDate date);
    List<Reservation> findByMember_IdOrderByReservationDateDesc(Long memberId);
    long countByStatus(ReservationStatus status);
}
