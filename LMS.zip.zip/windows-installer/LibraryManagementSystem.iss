#ifndef AppImageDir
  #error AppImageDir must be passed to the Inno Setup compiler
#endif

[Setup]
AppId={{9F406E2A-2D17-41AF-8E4B-8EE2E4A67D1A}
AppName=Local Library
AppVersion=1.0.0
AppPublisher=Local Library
DefaultDirName={localappdata}\Programs\Local Library
DefaultGroupName=Local Library
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=..\target\windows-installer
OutputBaseFilename=LocalLibrary-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Files]
Source: "{#AppImageDir}\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{group}\Local Library"; Filename: "{app}\LocalLibrary.exe"
Name: "{autodesktop}\Local Library"; Filename: "{app}\LocalLibrary.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\LocalLibrary.exe"; Description: "Start Local Library"; Flags: postinstall nowait skipifsilent
