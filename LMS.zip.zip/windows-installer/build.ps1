$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$outputRoot = Join-Path $projectRoot 'target\windows-installer'
$appInput = Join-Path $outputRoot 'input'
$appImageRoot = Join-Path $outputRoot 'app-image'
$appImage = Join-Path $appImageRoot 'LocalLibrary'
$jarName = 'library-management-system-1.0.0.jar'
$jarPath = Join-Path $projectRoot "target\$jarName"
if (-not $env:JAVA_HOME) {
    throw 'JAVA_HOME is not set. Set it to a JDK 17 or newer installation.'
}
$jpackage = Join-Path $env:JAVA_HOME 'bin\jpackage.exe'
$compiler = @(
    (Join-Path $env:LOCALAPPDATA 'Programs\Inno Setup 6\ISCC.exe'),
    (Join-Path $env:ProgramFiles 'Inno Setup 6\ISCC.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe')
) | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not (Test-Path $jpackage)) {
    throw "jpackage.exe was not found under JAVA_HOME ($env:JAVA_HOME). Install JDK 17 or newer and set JAVA_HOME."
}
if (-not $compiler) {
    throw 'Inno Setup 6 is required to create the Windows installer. Install it and rerun this script.'
}

Push-Location $projectRoot
try {
    & mvn -DskipTests package
    if ($LASTEXITCODE -ne 0) {
        throw "Maven package failed with exit code $LASTEXITCODE."
    }

    New-Item -ItemType Directory -Force -Path $appInput, $appImageRoot | Out-Null
    Copy-Item -Force $jarPath (Join-Path $appInput $jarName)
    if (Test-Path $appImage) {
        Remove-Item -Recurse -Force $appImage
    }

    & $jpackage `
        --type app-image `
        --name LocalLibrary `
        --app-version 1.0.0 `
        --input $appInput `
        --main-jar $jarName `
        --main-class org.springframework.boot.loader.launch.JarLauncher `
        --dest $appImageRoot `
        --java-options '-Dlibrary.desktop.open-browser=true' `
        --win-console
    if ($LASTEXITCODE -ne 0) {
        throw "jpackage failed with exit code $LASTEXITCODE."
    }

    & $compiler "/DAppImageDir=$appImage" (Join-Path $PSScriptRoot 'LibraryManagementSystem.iss')
    if ($LASTEXITCODE -ne 0) {
        throw "Inno Setup failed with exit code $LASTEXITCODE."
    }
} finally {
    Pop-Location
}
