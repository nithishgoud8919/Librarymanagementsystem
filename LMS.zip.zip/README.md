# Local Library Management System

A local-only library application built with Java 17, Spring Boot, Spring Data JPA, Spring Security, MySQL, and static HTML/CSS/vanilla JavaScript. Spring Boot serves both the UI and JSON API from `http://localhost:8080`; browser code never connects directly to MySQL.

## Requirements

- JDK 17 or newer
- Maven 3.6+
- MySQL 8.x running on `localhost:3306`

## MySQL setup

The configured JDBC endpoint is `localhost:3306/library_db`. On this computer the `MySQL80` Windows service is already running and TCP port 3306 is accepting local connections, so no service activation is needed. To check it later in PowerShell:

```powershell
Get-Service MySQL80
Test-NetConnection 127.0.0.1 -Port 3306
```

If the service is stopped, start PowerShell as Administrator and run `Start-Service MySQL80`.

Create the local database:

```sql
CREATE DATABASE library_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Use either of your existing MySQL accounts that is permitted to use `library_db`. If needed, have a MySQL administrator grant the chosen existing account access to this schema (replace `existing_user` with that account's MySQL username):

```sql
GRANT ALL PRIVILEGES ON library_db.* TO 'existing_user'@'localhost';
```

Configure the selected account's credentials in the PowerShell window that will run the application:

PowerShell:

```powershell
$env:DB_USERNAME = "your-existing-mysql-username"
$env:DB_PASSWORD = "your-existing-mysql-password"
```

Do not commit or share your database password. The checked-in property uses the conspicuous placeholder `YOUR_MYSQL_PASSWORD`; setting `DB_PASSWORD` overrides it. Hibernate creates/updates tables (`ddl-auto=update`); roles and demo rows are seeded idempotently at startup.

## Run locally

From the project root:

```powershell
mvn spring-boot:run
```

Or build and launch the jar:

```powershell
mvn -DskipTests package
java -jar target/library-management-system-1.0.0.jar
```

Open [http://localhost:8080](http://localhost:8080). Maven test execution is not part of this project setup.

### Windows desktop installer

The Windows installer packages the application and its Java runtime. It uses the local MySQL server; MySQL must already be installed and running on the computer. Set `DB_USERNAME` and `DB_PASSWORD` in the Windows user environment before starting the app. Do not put database credentials in the installer or commit them to the project.

To build the installer, install JDK 17 or newer, Maven, and Inno Setup 6, set `JAVA_HOME` to the JDK directory, then run from the project root:

```powershell
.\windows-installer\build.ps1
```

The installer is written to `target\windows-installer\LocalLibrary-Setup.exe`. After installation, launch **Local Library** from the Start menu or desktop shortcut. It starts the backend and opens the sign-in page in the default browser.

## Install on a phone or computer

The responsive web app is installable as a Progressive Web App (PWA). On the same computer, open `http://localhost:8080` in Chrome or Edge and choose **Install app** when offered, or use the browser's install option. On iPhone or iPad, open the app in Safari and choose **Share > Add to Home Screen**.

To install on a phone while the server runs on a computer, the phone must be able to reach the server over the network and the site must use HTTPS; `localhost` on the phone refers to the phone itself. Configure an HTTPS address and allow that port through the computer's firewall before opening the site on the phone. The app needs its server connection for sign-in and live library data; only the UI shell is cached for offline startup.

### Android APK

An Android WebView wrapper project is in `android-app`. It opens the existing library app rather than running the Spring Boot server or MySQL on the phone. The APK's server address is configured in `MainActivity.java`; the current build targets `http://192.168.0.118:8080/`, matching the Spring Boot port in `src/main/resources/application.properties`. Keep the library server running on the computer and connect the phone and computer to the same Wi-Fi network. If the computer's local IP changes, update `APP_URL` before building. Android may require allowing installation from the browser or file manager that opens the APK.

Build a debug-installable APK from `android-app` using JDK 17, Android SDK Platform 35, and Gradle 8.9 or newer compatible with Android Gradle Plugin 8.7.3:

```powershell
gradle assembleDebug
```

The APK is written to `android-app\app\build\outputs\apk\debug\app-debug.apk`.

## Initial accounts

| Role | Email | Password |
| --- | --- | --- |
| Administrator | `admin@library.local` | `Admin@123` |
| Librarian | `librarian@library.local` | `Librarian@123` |
| Sample member | `member@library.local` | `Member@123` |

These are development-only credentials. Change them after first sign-in. Passwords are persisted as BCrypt hashes. Accounts with a status other than `ACTIVE` cannot log in.

## Included features

- Role-checked local session login/logout and profile access
- Catalog search by keyword, category, and author; book archive and copy inventory
- Admin dashboard showing total librarians, members, active titles, physical copies, available books, books taken, and overdue books
- Admins and librarians can add up to 100 physical copies per batch, with unique copy codes generated automatically
- Member dashboards focused on current loans and the book collection, with searchable, paginated title, publication, availability, and rack/row details
- Responsive, installable Progressive Web App with an offline-cached UI shell
- Librarians can record the actual issue date for a book issued earlier; due dates are calculated from that date
- Member/librarian account management and account status changes (admin)
- Borrowing limit of 5 active books and a 14-day loan period
- Return/lost-copy recording, automatic overdue and lost-copy fines, partial payments, and fine waivers
- First-come-first-served reservations, three-day ready holds, and automatic expiry processing
- Role-specific dashboards and inventory, circulation, overdue, fine, popularity, and category reports
- Responsive UI pages served locally from `src/main/resources/static`

The borrowing policy and fine values are centralized in `com.example.library.config.CirculationPolicy`.

## REST API

All API paths use `/api`. Requests and responses use JSON; login creates a same-origin HTTP session cookie.

### Authentication

| Method | Path | Access |
| --- | --- | --- |
| POST | `/auth/login` | Public; `{ "email": "...", "password": "..." }` |
| POST | `/auth/logout` | Authenticated session |
| GET | `/auth/me` | Authenticated |

### Users and members

| Method | Path | Access |
| --- | --- | --- |
| GET | `/users?keyword=&role=` | Admin/librarian |
| GET | `/users/{id}` | Admin/librarian; members may read themselves |
| POST | `/users` | Admin/librarian (librarians may create members only) |
| PUT | `/users/{id}` | Admin/librarian |
| PATCH | `/users/{id}/status` | Admin |
| PUT | `/users/{id}/profile` | Own profile |
| GET | `/users/{userId}/borrowings` | Admin/librarian; member own history |
| GET | `/users/{userId}/fines` | Admin/librarian; member own fines |

### Books, copies, and circulation

| Method | Path | Access |
| --- | --- | --- |
| GET | `/books?keyword=&category=&author=` | Authenticated |
| GET | `/books/search?keyword=`; GET `/books/{id}` | Authenticated |
| POST/PUT | `/books`; `/books/{id}` | Admin/librarian |
| PATCH | `/books/{id}/archive` | Admin/librarian |
| GET/POST | `/books/{bookId}/copies` | Read: authenticated; write: admin/librarian |
| GET | `/copies` | Admin/librarian |
| PUT | `/copies/{id}`; PATCH `/copies/{id}/status` | Admin/librarian |
| GET | `/borrowings`; GET `/borrowings/{id}` | Staff; a member may read their own transaction |
| POST | `/borrowings` | Admin/librarian; `{ "memberId": 1, "copyId": 1 }` |
| POST | `/borrowings/{id}/return` | Admin/librarian; `{ "condition": "GOOD", "lost": false }` |
| GET | `/borrowings/overdue` | Admin/librarian |

### Reservations and fines

| Method | Path | Access |
| --- | --- | --- |
| GET | `/reservations` | Admin/librarian |
| GET | `/reservations/mine`; POST `/reservations` | Member |
| DELETE/PATCH | `/reservations/{id}`; `/reservations/{id}/cancel` | Owner or staff |
| GET | `/fines` | Admin/librarian |
| GET | `/fines/mine` | Member |
| POST | `/fines/{id}/payment` | Admin/librarian; `{ "amount": 2.00, "notes": "Cash" }` |
| POST | `/fines/{id}/waive` | Admin/librarian |

### Dashboards and reports

| Method | Path | Access |
| --- | --- | --- |
| GET | `/dashboard/admin` | Admin |
| GET | `/dashboard/librarian` | Admin/librarian |
| GET | `/dashboard/member` | Authenticated (returns the signed-in member's summary) |
| GET | `/reports/inventory`, `/reports/borrowings`, `/reports/overdue`, `/reports/fines` | Admin/librarian |
| GET | `/reports/most-borrowed`, `/reports/categories` | Admin/librarian |
| GET | `/reports/member-history?memberId={id}` | Admin/librarian |

Errors use a JSON object with `timestamp`, `status`, and a safe `error` message. Validation failures return HTTP 400; missing records 404; duplicate data 409; unauthenticated requests 401; denied roles 403.

## Project layout

```text
src/main/java/com/example/library/
  config/       Security, circulation policy, and idempotent seed data
  controller/   REST API endpoints
  dto/          Validated request and response records
  entity/       JPA entities and status enums
  exception/    Domain exceptions and JSON exception advice
  repository/   Spring Data JPA repositories
  security/     Session authentication filter
  service/      Transactional business operations
src/main/resources/
  application.properties
  static/       HTML pages, CSS, and vanilla JavaScript
```

This application is intended for local development. It has no cloud, external API, payment gateway, email, SMS, GPS, or mobile-app integration.
