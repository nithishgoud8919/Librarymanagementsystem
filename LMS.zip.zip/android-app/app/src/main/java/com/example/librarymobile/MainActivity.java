package com.example.librarymobile;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String APP_URL = "http://192.168.0.118:8080/";

    private WebView webView;
    private LinearLayout connectionError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);

        TextView message = new TextView(this);
        message.setText("Can't connect to the library server.\n\n"
                + "Connect this device to the same Wi-Fi as the library computer "
                + "and make sure the app is running.");
        message.setTextColor(Color.rgb(38, 50, 45));
        message.setTextSize(16);
        message.setGravity(Gravity.CENTER);
        message.setPadding(32, 24, 32, 24);

        Button retry = new Button(this);
        retry.setText("Try again");
        retry.setOnClickListener(view -> loadLibrary());

        connectionError = new LinearLayout(this);
        connectionError.setOrientation(LinearLayout.VERTICAL);
        connectionError.setGravity(Gravity.CENTER);
        connectionError.setPadding(24, 24, 24, 24);
        connectionError.setBackgroundColor(Color.rgb(248, 249, 246));
        connectionError.addView(message);
        connectionError.addView(retry);
        connectionError.setVisibility(View.GONE);

        FrameLayout layout = new FrameLayout(this);
        layout.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        layout.addView(connectionError, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(layout);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri.getHost() != null
                        && uri.getHost().equals(Uri.parse(APP_URL).getHost())
                        && ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme()))) {
                    return false;
                }
                try {
                    startActivity(new android.content.Intent(
                            android.content.Intent.ACTION_VIEW, uri));
                } catch (android.content.ActivityNotFoundException exception) {
                    Toast.makeText(MainActivity.this, "No app can open this link.", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                connectionError.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(
                    WebView view,
                    WebResourceRequest request,
                    android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {
                    connectionError.setVisibility(View.VISIBLE);
                }
            }
        });

        if (savedInstanceState == null || webView.restoreState(savedInstanceState) == null) {
            loadLibrary();
        }
    }

    private void loadLibrary() {
        connectionError.setVisibility(View.GONE);
        webView.loadUrl(APP_URL);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
